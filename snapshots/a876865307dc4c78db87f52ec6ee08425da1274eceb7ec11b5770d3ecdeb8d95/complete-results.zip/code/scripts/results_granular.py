"""Refresh source-native local counts without changing their geographic qualifications."""

import copy
import csv
import gzip
from html.parser import HTMLParser
import io
import json
from pathlib import PurePosixPath
import re
from urllib.parse import quote, unquote, urlsplit, urlunsplit
import zipfile

from scripts.current import reporting_counts
from scripts.participation_intake.contract import (
    IntakeError, count, digest, encoded, observation_id, pin, validate,
)


MN_URL = "https://electionresultsfiles.sos.mn.gov/20261103/pctstats.txt"
CT_ROOT = "https://ctemspublic.tgstg.net/ng-app/data/"
CT_VERSION = CT_ROOT + "election/108/Version.json"
CT_ELECTIONS = CT_ROOT + "Elections.json"
MN_FIELDS = ("state", "county_id", "precinct_id", "precinct_name", "has_reported_statistics",
             "registered_7am", "registered_election_day", "roster_signatures",
             "regular_military_overseas_absentee", "federal_only_absentee",
             "president_only_absentee", "total_number_voted")
PRIVATE_HEADERS = re.compile(
    r"voter.?id|voter.?name|first.?name|last.?name|ncid|registration.?number|date.?of.?birth|birth.?date|"
    r"\bdob\b|residen(?:ce|tial).?address|street.?address|email|phone|social.?security|"
    r"api.?key|access.?token|password|github_pat_|ghp_", re.I)
NOT_RESULTS = re.compile(
    r"primary|runoff|special|sample.?ballot|voter.?guide|voters.?pamphlet|cvr|cast.?vote.?record|"
    r"voter.?file|voter.?list|voter.?histor|individual.?voter|registration.?extract|"
    r"poll.?book|candidate.?filing", re.I)


def selected_records(baseline, state):
    index = json.loads(baseline["index.json"])
    item = index["states"][state]
    shard = json.loads(gzip.decompress(baseline[item["file"]]))
    selected = {identity for frame in shard.get("views", {}).values()
                for partition in ("counties", "precincts", "nongeographic")
                for identity in frame.get(partition, [])}
    return [row for row in shard["records"] if row["id"] in selected]


def native_template_pin(template):
    required = ("id", "election", "geography", "measure", "denominator",
                "count", "source_clock", "source")
    if any(key not in template for key in required) or "value" not in template["count"]:
        return None
    source = template["source"]
    return pin(encoded({
        **{key: template[key] for key in ("id", "election", "geography", "measure", "denominator")},
        "count": {key: template["count"][key] for key in ("value", "status")},
        "source_clock": {key: template["source_clock"].get(key) for key in ("literal", "timezone")},
        "source": {key: source.get(key) for key in ("id", "url", "classification")},
    }))


def change(template, value, native, *, registered=None, clock=None,
           reported=None, total=None, rate_compatible=False):
    return {"id": template["id"], "value": value, "native": native,
            "registered": registered, "clock": clock, "reported_units": reported,
            "total_units": total, "rate_compatible": rate_compatible,
            "reviewed_template_pin": native_template_pin(template)}


def north_carolina(body, templates):
    rows, audit = reporting_counts(json.loads(body))
    by_id = {row["county_id"]: row for row in rows}
    updates = []
    for template in templates:
        native = template.get("view", {}).get("native_record", {}).get("query", {})
        identity = str(native.get("county_id", ""))
        if not identity:
            continue
        row = by_id.get(identity)
        expected = "STATEWIDE" if identity == "0" else template["geography"]["name"]
        if row is None or row["county"] != expected:
            raise ValueError("Changed NC native county identity/name")
        updates.append(change(template, row["ballots_cast"], row,
            registered=row["registered_voters"], clock=row["source_update_label"],
            reported=row["precincts_reporting"], total=row["precincts_total"],
            rate_compatible=row["reported_ballot_fraction_pct"] is not None))
    return {"updates": updates, "complete_native_query": rows, "reconciliation": audit,
            "geographic_joins_changed": False}


def minnesota(body, templates):
    raw = list(csv.reader(io.StringIO(body.decode("utf-8-sig")), delimiter=";"))
    units = {}
    for values in raw:
        if (len(values) != len(MN_FIELDS) or values[0] != "MN"
                or values[4] not in ("0", "1") or not values[1] or not values[2]):
            raise ValueError("Changed Minnesota native statistical schema")
        row = dict(zip(MN_FIELDS, values[:5] + [count(value) for value in values[5:]]))
        if any(value is None for value in row.values()):
            raise ValueError("Missing native Minnesota count is not zero")
        key = row["county_id"], row["precinct_id"]
        if key in units:
            raise ValueError("Duplicate Minnesota county-scoped precinct")
        units[key] = row
    expected = {}
    for template in templates:
        native = template.get("view", {}).get("native_record", {})
        if "precinct_id" in native:
            expected[native["county_id"], native["precinct_id"]] = native["precinct_name"]
    if not expected or set(units) != set(expected):
        raise ValueError("Minnesota source/reference inventory changed; no inferred geographic join")
    if any(row["precinct_name"] != expected[key] for key, row in units.items()):
        raise ValueError("Minnesota native reporting-unit name changed")
    parents = {}
    for row in units.values():
        parent = parents.setdefault(row["county_id"], [])
        parent.append(row)
    queries, updates = [], []
    for template in templates:
        native = template.get("view", {}).get("native_record", {})
        if "precinct_id" in native:
            row = units[native["county_id"], native["precinct_id"]]
            value = row["total_number_voted"] if row["has_reported_statistics"] == "1" else None
            updates.append(change(template, value, row))
        elif native.get("native_county_id") in parents:
            all_rows = parents[native["native_county_id"]]
            reported = [row for row in all_rows if row["has_reported_statistics"] == "1"]
            complete = len(reported) == len(all_rows)
            subtotal = sum(row["total_number_voted"] for row in reported)
            registered = sum(row["registered_7am"] + row["registered_election_day"] for row in reported)
            conflicts = sum(row["total_number_voted"] != sum(row[key] for key in MN_FIELDS[7:11])
                            for row in reported)
            excesses = sum(row["total_number_voted"] > row["registered_7am"] + row["registered_election_day"]
                           for row in reported)
            query = {"native_county_id": native["native_county_id"],
                     "county": template["geography"]["name"],
                     "reported_statistics": len(reported), "reference_precincts": len(all_rows),
                     "reported_subtotal": subtotal, "all_statistics_reported": complete,
                     "native_component_conflicts": conflicts, "native_electorate_excesses": excesses,
                     "total_number_voted": subtotal if complete else None,
                     "derived_7am_plus_election_day_registration": registered if complete else None}
            queries.append(query)
            updates.append(change(template, query["total_number_voted"], query,
                registered=query["derived_7am_plus_election_day_registration"],
                reported=len(reported), total=len(all_rows),
                rate_compatible=complete and not conflicts and not excesses and registered > 0))
    return {"updates": updates, "complete_native_query": list(units.values()),
            "county_queries": queries, "geographic_joins_changed": False,
            "source_clock": None, "clock_qualification": "No count clock in native statistical TXT"}


def connecticut(turnout, election, elections, status, templates):
    event = [row for row in elections if row.get("ID") == "108"]
    if (len(event) != 1 or event[0].get("Name") != "11/03/2026 -- November 2026 State Election"
            or election.get("ID") != "108" or set(turnout) != {str(i) for i in range(1, 171)}
            or set(status) != {str(i) for i in range(1, 170)}
            or turnout["170"].get("NM") != "Total"):
        raise ValueError("Changed Connecticut election or complete native town inventory")
    fields = ("EV", "VV", "ABR", "ABC", "EBR", "EBC", "EDR", "EDC")
    for field in fields:
        total = count(turnout["170"].get(field))
        values = [count(turnout[str(i)].get(field)) for i in range(1, 170)]
        if total is None or any(value is None for value in values) or sum(values) != total:
            raise ValueError("Connecticut complete town/native Total discrepancy")
    if (count(election.get("BC")) != count(turnout["170"]["VV"])
            or count(election.get("RV")) != count(turnout["170"]["EV"])):
        raise ValueError("Connecticut separate election parent disagrees")
    updates = []
    for template in templates:
        identity = template.get("view", {}).get("source_town_id")
        if not identity:
            continue
        native = turnout.get(identity)
        if native is None or native.get("NM") != template["geography"]["name"]:
            raise ValueError("Changed literal Connecticut town identity")
        updates.append(change(template, count(native["VV"]),
            {**native, "source_town_id": identity, "town_status": status[identity]}))
    return {"updates": updates, "complete_native_query": turnout,
            "election_parent": election, "town_status": status,
            "geographic_joins_changed": False, "source_clock": None}


def alabama(body, templates):
    import xlrd

    units, parents, queries = {}, {}, []
    with zipfile.ZipFile(io.BytesIO(body)) as archive:
        entries = archive.infolist()
        if (len(entries) > 500 or sum(item.file_size for item in entries) > 200_000_000
                or any(item.flag_bits & 1 for item in entries)):
            raise ValueError("Unqualified Alabama workbook archive inventory")
        for item in entries:
            name = PurePosixPath(item.filename).name
            match = re.fullmatch(r"2026_GENERAL_ELECTION-(.+)\.xls", name, re.I)
            if not match:
                continue
            county = match[1]
            workbook = xlrd.open_workbook(file_contents=archive.read(item))
            sheet = workbook.sheet_by_name("Precinct Results")
            if sheet.nrows < 3 or sheet.ncols < 4:
                raise ValueError("Incomplete Alabama statistics workbook")
            labels = [" ".join(str(sheet.cell_value(row, col)).upper().split())
                      for row in (1, 2) for col in range(3)]
            if not any("BALLOTS CAST" in label and "TOTAL" in label for label in labels[3:]):
                raise ValueError("Alabama physical statistic row/header changed")
            selected = []
            for col in range(3, sheet.ncols):
                label = sheet.cell_value(0, col)
                if label == "":
                    continue
                if not isinstance(label, str):
                    raise ValueError("Changed Alabama reporting-unit label")
                native_values = [sheet.cell_value(row, col) for row in (1, 2)]
                if any(value != "" and (type(value) not in (int, float)
                       or int(value) != value or value < 0) for value in native_values):
                    raise ValueError("Missing/fractional Alabama native statistical count")
                registered, ballots = (None if value == "" else int(value) for value in native_values)
                column, number = "", col + 1
                while number:
                    number, remainder = divmod(number - 1, 26)
                    column = chr(65 + remainder) + column
                row = {"county": county, "unit": label, "column": column,
                       "ballots": ballots, "registered": registered, "workbook": name,
                       "source_rows": [{"workbook": name, "table": "Precinct Results",
                                        "column": column,
                                        "rows_by_field": {"unit": 1, "registered": 2, "ballots": 3}}]}
                key = county, column
                if key in units:
                    raise ValueError("Duplicated Alabama workbook/physical column")
                units[key] = row
                selected.append(row)
            if not selected:
                raise ValueError("Empty Alabama statistical table")
            subtotal = sum(row["ballots"] for row in selected if row["ballots"] is not None)
            parents[county.upper()] = {"county": county,
                "ballots": subtotal if all(row["ballots"] is not None for row in selected) else None,
                "reported_subtotal": subtotal,
                "source_units": len(selected), "derived_source_column_sum": True,
                "native_printed_county_parent": False}
            queries.extend(selected)
    if not units:
        raise ValueError("No explicitly named 2026 general-election statistics workbooks")
    updates = []
    parent_sources = {}
    for template in templates:
        native = template.get("view", {}).get("native_record", {})
        for source in native.get("source_rows", []):
            match = re.fullmatch(r"2026_GENERAL_ELECTION-(.+)\.xls", source.get("workbook", ""), re.I)
            parent_id = template["geography"].get("parent_id")
            if match and parent_id:
                previous = parent_sources.setdefault(parent_id, match[1].upper())
                if previous != match[1].upper():
                    raise ValueError("An accepted Alabama parent points at conflicting native workbooks")
    for template in templates:
        native = template.get("view", {}).get("native_record", {})
        if template["geography"]["level"] == "county":
            source_county = parent_sources.get(template["geography"]["id"],
                                               template["geography"]["name"].upper())
            parent = parents.get(source_county)
            if parent:
                updates.append(change(template, parent["ballots"], parent))
        elif native.get("column") and native.get("source_rows"):
            source = native["source_rows"][0]
            match = re.fullmatch(r"2026_GENERAL_ELECTION-(.+)\.xls", source.get("workbook", ""), re.I)
            row = units.get((match[1], native["column"])) if match else None
            if row is None or row["unit"] != template["geography"]["name"]:
                raise ValueError("Changed Alabama native column identity; old unit is not reassigned")
            updates.append(change(template, row["ballots"], row))
    return {"updates": updates, "complete_native_query": queries, "county_queries": list(parents.values()),
            "geographic_joins_changed": False, "county_totals_are_explicit_derived_column_sums": True}


def eligible_product(link):
    url = urlsplit(link["url"])
    label = unquote(link.get("text", "") + " " + url.path + " " + url.query)
    return (url.scheme == "https" and not NOT_RESULTS.search(label)
            and bool(re.search(r"(?<!\d)2026(?!\d)", label))
            and bool(re.search(r"general|11[-_/]?03|nov(?:ember)?[ _-]*3", label, re.I)))


def transport_url(url):
    parsed = urlsplit(url)
    return urlunsplit((parsed.scheme, parsed.netloc, quote(parsed.path, safe="/%:@"),
                      quote(parsed.query, safe="=&%+/:@"), ""))


def public_facts(value):
    if isinstance(value, dict):
        if any(PRIVATE_HEADERS.search(str(key)) for key in value):
            raise ValueError("Individual/contact schema is excluded from public numerical intake")
        for item in value.values():
            public_facts(item)
    elif isinstance(value, (list, tuple)):
        for item in value:
            public_facts(item)
    elif isinstance(value, str) and PRIVATE_HEADERS.search(value):
        raise ValueError("Individual/contact schema is excluded from public numerical intake")
    return value


def archive_members(archive, budget):
    items = archive.infolist()
    budget["members"] -= len(items)
    budget["bytes"] -= sum(item.file_size for item in items)
    if (budget["members"] < 0 or budget["bytes"] < 0
            or len({item.filename for item in items}) != len(items)
            or any(item.flag_bits & 1 for item in items)):
        raise ValueError("Unqualified declared archive size/inventory")
    return items


class FactualHTMLTables(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.tables, self.table, self.row, self.cell = [], None, None, None
        self.depth, self.hidden, self.nested = 0, 0, False

    def handle_starttag(self, tag, attributes):
        if tag in ("script", "style"):
            self.hidden += 1
        if tag == "table":
            self.depth += 1
            if self.depth == 1:
                self.table = {"attributes": {key: value for key, value in attributes if key == "id"},
                              "rows": []}
            else:
                self.nested = True
        elif self.depth == 1 and tag == "tr":
            self.row = {"row": len(self.table["rows"]) + 1, "cells": []}
            self.table["rows"].append(self.row)
        elif self.depth == 1 and tag in ("td", "th") and self.row is not None:
            self.cell = {"kind": tag, "attributes": {
                key: value for key, value in attributes
                if key in ("id", "headers", "scope", "colspan", "rowspan")}, "value": ""}
            self.row["cells"].append(self.cell)

    def handle_endtag(self, tag):
        if tag in ("script", "style"):
            self.hidden = max(0, self.hidden - 1)
        if tag == "table":
            if self.depth == 1 and self.table is not None:
                self.tables.append(self.table)
                self.table, self.row, self.cell = None, None, None
            self.depth = max(0, self.depth - 1)
        elif self.depth == 1 and tag in ("td", "th"):
            self.cell = None
        elif self.depth == 1 and tag == "tr":
            self.row, self.cell = None, None

    def handle_data(self, text):
        if self.depth == 1 and self.cell is not None and not self.hidden:
            self.cell["value"] += text


def factual_tables(body, name, *, _budget=None, _depth=0):
    """Unrecognized numerical schemas stay factual queries, never turnout/model inputs."""
    from scripts.native_tabular import delimited, json_records, xlsx, xls

    if _depth > 3:
        raise ValueError("Declared nested archive exceeds the bounded intake depth")
    budget = _budget if _budget is not None else {"bytes": 200_000_000, "members": 1000}
    suffix = PurePosixPath(urlsplit(name).path).suffix.lower()
    if suffix in (".csv", ".txt"):
        encoding = "utf-16" if body.startswith((b"\xff\xfe", b"\xfe\xff")) else "utf-8-sig"
        text = body.decode(encoding)
        table = delimited(body, delimiter="\t" if "\t" in text[:4096] else ",", encoding=encoding)
        tables = [table]
    elif suffix == ".json":
        try:
            tables = [json_records(body)]
        except ValueError as error:
            if not any(marker in str(error) for marker in (
                    "record array is required", "explicit nested-field reader")):
                raise
            def unique(pairs):
                result = {}
                for key, value in pairs:
                    if key in result:
                        raise ValueError("Duplicate native JSON object key")
                    result[key] = value
                return result
            def nonfinite(value):
                raise ValueError("Nonfinite native JSON value: " + value)
            native = json.loads(body.decode("utf-8-sig"), object_pairs_hook=unique,
                                parse_constant=nonfinite)
            public_facts(native)
            return {"status": "complete_native_json_requires_measure_adapter",
                    "native_json": native, "numerical_data_qualified": False,
                    "candidate_votes_are_ballots": False}
    elif suffix in (".xlsx", ".xls"):
        if suffix == ".xlsx":
            with zipfile.ZipFile(io.BytesIO(body)) as archive:
                archive_members(archive, budget)
        product = (xlsx if suffix == ".xlsx" else xls)(body)
        public_facts(product)
        return {"status": "native_workbook_requires_measure_adapter",
                "native_inventory": [{"name": table["name"], "rows": table.get("nrows"),
                                      "columns": table.get("ncols")} for table in product],
                "tables": product, "complete_native_cells_retained": True,
                "numerical_data_qualified": False, "candidate_votes_are_ballots": False}
    elif suffix == ".zip":
        with zipfile.ZipFile(io.BytesIO(body)) as archive:
            items = archive_members(archive, budget)
            selected, dispositions = {}, []
            for item in items:
                path = PurePosixPath(item.filename)
                if item.is_dir():
                    continue
                if (path.is_absolute() or ".." in path.parts or "\\" in item.filename
                        or NOT_RESULTS.search(item.filename)):
                    dispositions.append({"member": item.filename, "status": "excluded_scope_or_path"})
                    continue
                if path.suffix.lower() in (".csv", ".txt", ".json", ".xlsx", ".xls", ".zip"):
                    selected[item.filename] = factual_tables(archive.read(item), item.filename,
                        _budget=budget, _depth=_depth + 1)
                else:
                    dispositions.append({"member": item.filename, "status": "format_requires_review"})
            return {"status": "complete_declared_tabular_queries", "members": selected,
                    "member_dispositions": dispositions, "numerical_data_qualified": False}
    elif suffix in ("", ".html", ".htm", ".aspx", ".shtml"):
        parser = FactualHTMLTables()
        parser.feed(body.decode("utf-8-sig"))
        parser.close()
        if parser.depth or parser.nested:
            raise ValueError("Incomplete/nested native HTML tables require a structural adapter")
        tables = parser.tables
        if not tables:
            return {"status": "source_format_requires_measure_adapter", "numerical_data_qualified": False}
    else:
        return {"status": "source_format_requires_measure_adapter", "numerical_data_qualified": False}
    public_facts(tables)
    return {"status": "complete_native_table_requires_measure_adapter", "tables": tables,
            "numerical_data_qualified": False, "candidate_votes_are_ballots": False}


def collect(collector, baseline):
    from scripts import results_minnesota_turnout

    jobs = results_minnesota_turnout.collect_pair(collector, baseline)
    templates = selected_records(baseline, "AL")
    urls = {row["view"].get("source_url") for row in templates
            if row.get("view", {}).get("native_record", {}).get("source_rows")
            and row["measure"]["kind"] == "ballots_cast"}
    for url in sorted(value for value in urls if value and value.lower().endswith(".zip")):
        key = "AL-native-local"
        jobs[key] = collector.capture(key, url, lambda body: alabama(body, templates))
    templates = selected_records(baseline, "CT")
    if templates:
        def capture_ct(version_body):
            elections, _ = collector.acquire(CT_ELECTIONS)
            number = json.loads(version_body).get("Version")
            if type(number) is not int or number < 52337:
                raise ValueError("Invalid/regressed Connecticut native source version")
            base = CT_ROOT + "election/108/" + str(number) + "/"
            inputs = {}
            for name in ("voterTurnout_Electiondata", "election_Electiondata", "townStatus_Electiondata"):
                body, _ = collector.acquire(base + name + ".json")
                inputs[name] = body
            after, _ = collector.acquire(CT_VERSION, refresh=True)
            if json.loads(after).get("Version") != number:
                raise ValueError("Connecticut version changed during capture; retain last consistent snapshot")
            result = connecticut(*(json.loads(inputs[name]) for name in
                ("voterTurnout_Electiondata", "election_Electiondata")),
                json.loads(elections), json.loads(inputs["townStatus_Electiondata"]), templates)
            result["source_version"] = number
            result["numerical_input_pins"] = {name: pin(body) for name, body in inputs.items()}
            result["source_url"] = base + "voterTurnout_Electiondata.json"
            return result
        jobs["CT-native-local"] = collector.capture("CT-native-local", CT_VERSION, capture_ct)
    from scripts.results_native import collect_sources
    from scripts import (
        results_alaska_turnout, results_indiana_turnout, results_nc_vote_history, results_pa_vote_history,
        results_pdf_county_parent, results_turnout_history,
    )
    jobs.update(collect_sources(collector, baseline))
    jobs[results_alaska_turnout.FEED] = results_alaska_turnout.collect(collector)
    from scripts.results_state_statistics import HI_FEED, collect_hawaii
    jobs[HI_FEED] = collect_hawaii(collector)
    jobs[results_pdf_county_parent.IDENTITY] = results_pdf_county_parent.collect(collector)
    jobs[results_pdf_county_parent.WILSON_FEED] = results_pdf_county_parent.collect_wilson(collector)
    jobs[results_pdf_county_parent.SUMNER_FEED] = results_pdf_county_parent.collect_sumner(collector)
    jobs[results_pdf_county_parent.SUMMIT_FEED] = results_pdf_county_parent.collect_summit(collector)
    jobs[results_pdf_county_parent.SUSSEX_FEED] = results_pdf_county_parent.collect_sussex(collector)
    jobs[results_pdf_county_parent.DOUGLAS_FEED] = results_pdf_county_parent.collect_douglas(collector)
    jobs[results_pdf_county_parent.OKTIBBEHA_FEED] = results_pdf_county_parent.collect_oktibbeha(collector)
    jobs[results_pdf_county_parent.WOODFORD_FEED] = results_pdf_county_parent.collect_woodford(collector)
    jobs[results_pdf_county_parent.LAWRENCE_FEED] = results_pdf_county_parent.collect_lawrence(collector)
    jobs[results_pdf_county_parent.PHILADELPHIA_FEED] = results_pdf_county_parent.collect_philadelphia(collector)
    if jobs[results_pdf_county_parent.PHILADELPHIA_FEED].get("data") is not None:
        from scripts import philadelphia_divisions
        jobs[philadelphia_divisions.FEED] = philadelphia_divisions.collect(collector)
    jobs[results_turnout_history.WA_FEED] = results_turnout_history.collect_washington(collector)
    jobs[results_turnout_history.NC_HISTORY_FEED] = results_turnout_history.collect_north_carolina_history(collector)
    jobs[results_turnout_history.WY_HISTORY_FEED] = results_turnout_history.collect_wyoming_history(collector)
    jobs[results_turnout_history.WY_CANVASS_FEED] = results_turnout_history.collect_wyoming_precinct_canvass(collector)
    jobs[results_turnout_history.VA_FEED] = results_turnout_history.collect_virginia(collector)
    jobs[results_turnout_history.TX_FEED] = results_turnout_history.collect_texas(collector)
    jobs[results_turnout_history.KS_FEED] = results_turnout_history.collect_kansas(collector)
    jobs[results_turnout_history.NJ_FEED] = results_turnout_history.collect_new_jersey(collector)
    for feed, (_, capture) in results_turnout_history.municipal_feeds().items():
        jobs[feed] = capture(collector)
    jobs[results_turnout_history.OH_FEED] = results_turnout_history.collect_ohio(collector)
    jobs[results_turnout_history.MT_FEED] = results_turnout_history.collect_montana(collector)
    jobs[results_turnout_history.WV_FEED] = results_turnout_history.collect_west_virginia(collector)
    jobs[results_turnout_history.ND_CANVASS_FEED] = results_turnout_history.collect_north_dakota_canvass(collector)
    jobs[results_turnout_history.GA_FEED] = results_turnout_history.collect_georgia(collector)
    for year, feed in results_pa_vote_history.FEEDS.items():
        jobs[feed] = results_pa_vote_history.collect(collector, year)
    jobs[results_nc_vote_history.FEED] = results_nc_vote_history.collect(collector)
    for year, feed in results_indiana_turnout.FEEDS.items():
        jobs[feed] = results_indiana_turnout.collect(collector, year)
    for feed in (*results_turnout_history.COUNTY_ARCHIVES, results_turnout_history.CA_CURRENT_FEED):
        jobs[feed] = results_turnout_history.collect_county_archive(collector, feed, reuse_checked_week=True)
    from scripts import national_turnout_release_watch, nebraska_county_reports
    from scripts import oregon_turnout_history, washington_participation

    for feed in national_turnout_release_watch.INDEXES:
        jobs[feed] = national_turnout_release_watch.collect(collector, feed, reuse_checked_week=True)
    jobs[washington_participation.FEED] = washington_participation.collect(collector, reuse_checked_week=True)
    for feed in oregon_turnout_history.URLS:
        jobs[feed] = oregon_turnout_history.collect(collector, feed, reuse_checked_week=True)
    jobs[nebraska_county_reports.FEED] = nebraska_county_reports.collect(collector, check_unchanged=False)
    return jobs


def identity_fields(row):
    return (row["source"]["id"], row["election"]["id"], row["geography"]["id"],
            row["measure"]["id"], row["measure"]["mode"])


def validate_projected_row(old, row):
    try:
        validate(row)
        return None
    except IntakeError as error:
        if error.code != "observation_identity":
            raise
    expected = observation_id(*identity_fields(row))
    if (row["id"] != old["id"] or identity_fields(row) != identity_fields(old)
            or old["id"] == observation_id(*identity_fields(old))):
        raise IntakeError(
            "observation_identity",
            "A refresh cannot create or alter a legacy stable observation identity")
    probe = copy.deepcopy(row)
    probe["id"] = expected
    validate(probe)
    return expected


def _changed_leaf_paths(before, after, prefix=()):
    if isinstance(before, dict) and isinstance(after, dict):
        result = set()
        for key in set(before) | set(after):
            if key not in before or key not in after:
                result.add(".".join((*prefix, key)))
            else:
                result.update(_changed_leaf_paths(before[key], after[key], (*prefix, key)))
        return result
    return set() if before == after else {".".join(prefix)}


def reviewed_replacement(old, update, entry):
    bridge = update.get("reviewed_source_url_bridge")
    row = update.get("replacement")
    if (
        not isinstance(bridge, dict)
        or bridge.get("contract") != "participation.reviewed_source_url_bridge.v1"
        or not isinstance(row, dict)
        or not isinstance(row.get("view"), dict)
        or bridge.get("observation_id") != old["id"]
        or bridge.get("source_id") != old["source"]["id"]
        or update.get("id") != old["id"]
    ):
        raise ValueError("Reviewed source URL replacement declaration is incomplete")
    old_urls = old["source"]["url"], old["view"].get("source_url")
    reviewed_url = bridge.get("reviewed_url")
    stored_urls = bridge.get("stored_source_url"), bridge.get("stored_view_source_url")
    if old_urls == stored_urls:
        if (
            digest(encoded(old)) != bridge.get("accepted_prior_row_sha256")
            or old["source"]["input_sha256"] != bridge.get("retained_input_sha256")
        ):
            raise ValueError("Reviewed source URL bridge prior observation changed")
    elif old_urls != (reviewed_url, reviewed_url):
        raise ValueError("Reviewed source URL bridge does not authorize these stored URLs")
    source = entry.get("source") or {}
    query = (entry.get("data") or {}).get("complete_native_query")
    if (
        source.get("url") != reviewed_url
        or row.get("source", {}).get("url") != reviewed_url
        or row.get("view", {}).get("source_url") != reviewed_url
        or row.get("source", {}).get("input_sha256") != source.get("sha256")
        or not isinstance(query, list)
        or len(query) != 1
        or query[0].get("source_pin")
        != {"bytes": source.get("bytes"), "sha256": source.get("sha256")}
    ):
        raise ValueError("Reviewed source URL replacement disagrees with the captured input")
    row = copy.deepcopy(row)
    row["view"]["automatic_source_refresh"] = True
    allowed = bridge.get("allowed_replacement_paths")
    if (
        not isinstance(allowed, list)
        or any(not isinstance(path, str) or not path for path in allowed)
        or not _changed_leaf_paths(old, row) <= set(allowed) | {"view.automatic_source_refresh"}
        or identity_fields(row) != identity_fields(old)
        or row["id"] != old["id"]
        or row["count"]["value"] != update.get("value")
        or row["count"]["literal"] != update.get("value")
        or row["count"]["status"] != "reported"
        or row["source_clock"] != old["source_clock"]
        or row["reporting_status"] != old["reporting_status"]
        or row["denominator"] != old["denominator"]
    ):
        raise ValueError("Reviewed source URL replacement exceeded its explicit field scope")
    validate_projected_row(old, row)
    return row


def reviewed_source_bridge(entry, rows):
    data = entry.get("data") or {}
    bridge = data.get("reviewed_source_url_bridge")
    updates = data.get("updates")
    if bridge is None or (
            isinstance(updates, list)
            and any(isinstance(update, dict) and "replacement" in update for update in updates)):
        return None
    source = entry.get("source") or {}
    query = data.get("complete_native_query")
    if (
        not isinstance(bridge, dict)
        or bridge.get("contract") != "participation.reviewed_source_url_bridge.v1"
        or not isinstance(updates, list) or not updates
        or bridge.get("observation_ids_pin")
            != digest(encoded(sorted(update.get("id") for update in updates)))
        or not isinstance(bridge.get("prior_full_inventory_pin"), str)
        or not re.fullmatch(r"[a-f0-9]{64}", bridge["prior_full_inventory_pin"])
        or source.get("url") != bridge.get("reviewed_url")
        or not isinstance(query, list) or len(query) != 1
        or query[0].get("source_pin")
            != {"bytes": source.get("bytes"), "sha256": source.get("sha256")}
    ):
        raise ValueError("Reviewed source URL bridge declaration is incomplete")
    stored = bridge.get("stored_source_url"), bridge.get("stored_view_source_url")
    reviewed = bridge.get("reviewed_url")
    for update in updates:
        old = rows.get(update.get("id"))
        if (
            old is None
            or old["source"]["id"] != bridge.get("source_id")
            or (old["source"]["url"], old["view"].get("source_url"))
                not in (stored, (reviewed, reviewed))
        ):
            raise ValueError("Reviewed source URL bridge prior observation changed")
    return bridge


def project(baseline, granular):
    """Create successor bodies, preserving old versions, IDs, views and join decisions."""
    from scripts.national_turnout_release_watch import INDEXES as NATIONAL_RELEASE_INDEXES
    from scripts.oregon_turnout_history import URLS as OREGON_HISTORY_SOURCES
    from scripts.washington_participation import FEED as WA_AGGREGATE_WORKBOOK

    export_only = {*NATIONAL_RELEASE_INDEXES, *OREGON_HISTORY_SOURCES, WA_AGGREGATE_WORKBOOK}
    for key in granular.keys() & export_only:
        data = granular[key].get("data")
        if data is not None and (data.get("participation_observation_qualified") is not False
                                 or "updates" in data or "reviewed_count_addition" in data):
            raise ValueError("A historical workbook or national release index cannot project participation")
    granular = {key: entry for key, entry in granular.items() if key not in export_only}
    addition_changes = []
    for entry in granular.values():
        data = entry.get("data") if isinstance(entry, dict) else None
        addition = data.get("reviewed_count_addition") if isinstance(data, dict) else None
        if entry.get("status") == "reported" and addition is not None:
            from scripts.louisiana_bootstrap import apply_addition
            before_index = json.loads(baseline["index.json"])
            before_path = before_index["states"]["LA"]["file"]
            before_ids = {row["id"] for row in json.loads(
                gzip.decompress(baseline[before_path]))["records"]}
            baseline = apply_addition(baseline, addition)
            after_index = json.loads(baseline["index.json"])
            after_path = after_index["states"]["LA"]["file"]
            for row in json.loads(gzip.decompress(baseline[after_path]))["records"]:
                if row["id"] not in before_ids:
                    addition_changes.append({
                        "state_code": "LA", "id": row["id"], "previous": None,
                        "current": row["count"]["value"],
                        "source_status": "reviewed_addition",
                    })
    result = dict(baseline)
    index = json.loads(baseline["index.json"])
    changed = addition_changes
    by_state = {}
    for key, entry in sorted(granular.items()):
        if (entry.get("status") in ("reported", "retained_after_failure")
                and entry.get("data") is not None):
            by_state.setdefault(key.split("-")[0], []).append(entry)
    for state, entries in by_state.items():
        path = index["states"][state]["file"]
        shard = json.loads(gzip.decompress(baseline[path]))
        rows = {row["id"]: row for row in shard["records"]}
        state_changed = False
        for entry in entries:
            if entry["status"] == "retained_after_failure":
                updates = entry["data"].get("updates", [])
                if (not isinstance(entry.get("first_observed_at"), str)
                        or not entry["first_observed_at"] or not updates
                        or any(update.get("id") not in rows
                            or update.get("reviewed_template_pin") is None
                            or update.get("reviewed_template_pin") != native_template_pin(
                                rows[update["id"]]) for update in updates)):
                    continue
            reviewed_source_bridge(entry, rows)
            for update in entry["data"].get("updates", []):
                old = rows.get(update["id"])
                if old is None:
                    raise ValueError("A local refresh cannot invent an existing native identity")
                if "replacement" in update or "reviewed_source_url_bridge" in update:
                    row = reviewed_replacement(old, update, entry)
                    if row != old:
                        state_changed = True
                        changed.append({"state_code": state, "id": row["id"],
                                        "previous": old["count"]["value"],
                                        "current": row["count"]["value"],
                                        "source_status": entry["status"]})
                    rows[row["id"]] = row
                    continue
                row = copy.deepcopy(old)
                value, native = update["value"], update["native"]
                row["count"] = {"value": value, "literal": value,
                                "status": "reported" if value is not None else "unknown"}
                source = entry["source"]
                numerical_pins = entry["data"].get("numerical_input_pins", {})
                source_input = update.get("source_input")
                if source_input is None:
                    numerical_pin = numerical_pins.get("voterTurnout_Electiondata", source)
                    url = entry["data"].get("source_url", source["url"])
                else:
                    numerical_pin = numerical_pins.get(source_input)
                    declared = native.get("source_original_pin")
                    if (not isinstance(numerical_pin, dict)
                            or not isinstance(declared, dict)
                            or numerical_pin.get("url") != declared.get("url")
                            or numerical_pin.get("sha256") != declared.get("sha256")
                            or numerical_pin.get("bytes") != declared.get("bytes")
                            or native.get("source_input") != source_input):
                        raise ValueError("Native per-update numerical input declaration differs")
                    url = numerical_pin["url"]
                row["source"].update(url=url, input_sha256=numerical_pin["sha256"],
                                     selector={"native_refresh": native})
                timezone = native.get("source_clock_timezone_literal",
                                      native.get("pdf_report_timezone_literal"))
                if "source_clock_timezone_literal" in native and (
                        timezone != "UTC" or not isinstance(update["clock"], str)
                        or not update["clock"].endswith("Z")
                        or (native.get("query") or {}).get("source_clock_timezone_literal") != timezone):
                    raise ValueError("Native UTC clock/timezone disagrees with the complete query")
                row["source_clock"] = {"literal": update["clock"],
                                      "timezone": timezone,
                                      "qualification": "native_clock_or_explicitly_not_supplied"}
                denominator = row["denominator"]
                if denominator is not None:
                    denominator["value"] = update["registered"]
                    denominator["qualified"] = bool(denominator["qualified"] and update["rate_compatible"]
                        and value is not None and update["registered"] and value <= update["registered"])
                row["reporting_status"].update(reported_units=update["reported_units"],
                    total_units=update["total_units"],
                    complete=(update["reported_units"] == update["total_units"])
                    if update["total_units"] is not None
                    and native.get("native_reporting_complete_qualified") is not False else None)
                view = row["view"]
                view.update(ballots=value, native_record=native, source_url=url,
                    source_sha256=numerical_pin["sha256"], source_update_label=update["clock"],
                    denominator=update["registered"] if denominator else None,
                    reported_pct=100 * value / update["registered"] if denominator
                    and denominator["qualified"] else None,
                    reported_units=update["reported_units"], total_units=update["total_units"],
                    native_printed_pct=None)
                if "registered" in view:
                    view["registered"] = update["registered"]
                if "validated_pct" in view:
                    view["validated_pct"] = view["reported_pct"]
                if "native_source_updates" in native:
                    query = native.get("query") or {}
                    clocks = native["native_source_updates"]
                    if (clocks != query.get("native_source_updates")
                            or not isinstance(clocks, list) or not clocks
                            or any(not isinstance(item, dict)
                                or set(item) != {"source", "native_update_literal", "declared_timezone"}
                                or any(not isinstance(value, str) for value in item.values())
                                for item in clocks)
                            or native.get("source_date_literal") != update["clock"]
                            or native.get("source_date_literal") != query.get("source_date_literal")
                            or clocks[-1]["native_update_literal"] != update["clock"]):
                        raise ValueError("Native source-clock display facts disagree with the complete query")
                    view.update(source_date=native["source_date_literal"],
                                native_source_updates=copy.deepcopy(clocks))
                if "reviewed_measure_presentation_label" in native:
                    from scripts.automatic_native_refresh import reviewed_measure_label
                    label = native["reviewed_measure_presentation_label"]
                    query = native.get("query") or {}
                    if (label is None or label != reviewed_measure_label(old)
                            or label != query.get("reviewed_measure_presentation_label")
                            or query.get("source_url") != url
                            or query.get("source_pin") != {
                                key: numerical_pin[key] for key in ("bytes", "sha256")}):
                        raise ValueError("Reviewed measure display label is not source/query-bound")
                    view["participation_measure_label"] = label
                    view["participation_measure_literal_qualification"] = (
                        "Initial accepted source literal; current numerical equation is retained "
                        "in native_record, not reused as a fixed measure label.")
                if "native_fraction_literal" in native:
                    query = native.get("query") or {}
                    fraction = native["native_fraction_literal"]
                    status = native.get("native_report_status_literal")
                    if (not isinstance(fraction, str)
                            or not re.fullmatch(r"[0-9]+(?:\.[0-9]+)?%", fraction)
                            or fraction != query.get("native_fraction_literal")
                            or status != query.get("native_report_status_literal")
                            or status is not None and (
                                not isinstance(status, str) or not status.strip())):
                        raise ValueError("Native summary display facts disagree with the complete query")
                    view.update(native_printed_pct=fraction, source_status_literal=status)
                    row["reporting_status"]["literal"] = status
                elif "native_report_status_literal" in native:
                    status = native["native_report_status_literal"]
                    if (status != (native.get("query") or {}).get("native_report_status_literal")
                            or status is not None and (
                                not isinstance(status, str) or not status.strip())):
                        raise ValueError("Native PDF status disagrees with the complete query")
                    view["source_status_literal"] = status
                    row["reporting_status"]["literal"] = status
                if ("native_fraction_literal" in native
                        or native.get("retained_source_context_is_historical")):
                    prefix = "Retained earlier-report context (not current report statistics): "
                    if view.get("notes") and not view["notes"].startswith(prefix):
                        view["notes"] = prefix + view["notes"]
                    if view.get("quality") and not view["quality"][0].startswith(prefix):
                        view["quality"] = [prefix + view["quality"][0], *view["quality"][1:]]
                view["source_reporting_label"] = (
                    "Automatic same-source native statistical refresh. Missing reporting stays unknown; "
                    "source counts are not certification or independently observed people. "
                    "Prior geographic qualifications retained; no new boundary join or local model.")
                view["automatic_source_refresh"] = True
                if native.get("native_statewide_header") is True:
                    from scripts.results_state_statistics import apply_webforms_state_context
                    apply_webforms_state_context(old, row, numerical_pin)
                expected_identity = validate_projected_row(old, row)
                if expected_identity is not None:
                    view["legacy_stable_observation_id"] = {
                        "accepted_id": row["id"], "tuple_derived_id": expected_identity,
                        "identity_fields_changed": False,
                    }
                row["source"]["fields"] = copy.deepcopy(view)
                validate_projected_row(old, row)
                if row != old:
                    state_changed = True
                    changed.append({"state_code": state, "id": row["id"],
                                    "previous": old["count"]["value"], "current": value,
                                    "source_status": entry["status"]})
                rows[row["id"]] = row
        if not state_changed:
            continue
        shard["records"] = [rows[row["id"]] for row in shard["records"]]
        raw = bytearray(gzip.compress(encoded(shard), compresslevel=6, mtime=0))
        raw[9] = 3
        result[path] = bytes(raw)
        index["states"][state].update(pin(result[path]))
        declaration = index["states"][state]
        for mode, frame in shard.get("views", {}).items():
            description = declaration.get("views", {}).get(mode, {})
            for partition in ("counties", "precincts", "nongeographic"):
                selected = [rows[identity] for identity in frame.get(partition, [])]
                disposition = description.get("dispositions", {}).get(partition)
                if disposition is not None:
                    disposition.update(
                        reported=sum(row["count"]["status"] == "reported" for row in selected),
                        unknown=sum(row["count"]["status"] == "unknown" for row in selected),
                        withheld=sum(row["count"]["status"] == "withheld" for row in selected),
                        qualified_fractions=sum(bool(row["denominator"] and row["denominator"]["qualified"])
                                                for row in selected),
                        geography_levels=sorted({row["geography"]["level"] for row in selected}))
        if state in index.get("coverage", {}):
            records = shard["records"]
            index["coverage"][state].update(
                records=len(records),
                reported=sum(row["count"]["status"] == "reported" for row in records),
                unknown=sum(row["count"]["status"] == "unknown" for row in records),
                withheld=sum(row["count"]["status"] == "withheld" for row in records),
                zeros=sum(row["count"]["value"] == 0 for row in records),
                qualified_fractions=sum(bool(row["denominator"] and row["denominator"]["qualified"])
                                        for row in records))
    if changed:
        result["index.json"] = encoded(index)
    return result, changed
