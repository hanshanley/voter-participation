"""Compile pinned native factual grids and declarative queries without networking."""

import argparse
from datetime import datetime, timedelta
import gzip
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import re
import sys
import zipfile

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from scripts import native_tabular as tabular


def encoded(value):
    return (json.dumps(value, ensure_ascii=True, sort_keys=True,
        separators=(",", ":"), allow_nan=False) + "\n").encode()


def pin(body):
    return dict(bytes=len(body), sha256=hashlib.sha256(body).hexdigest())


def unpack(spec, body):
    if pin(body) != spec["pin"]:
        raise ValueError("Changed pinned native product: " + spec["id"])
    if spec["kind"] == "delimited":
        table = tabular.delimited(body, **spec["reader"])
        if len(table["rows"]) != spec["expected_rows"]:
            raise ValueError("Native record inventory changed")
        tables = [dict(kind="delimited", **table)]
    elif spec["kind"] == "json_records":
        table = tabular.json_records(body, **spec["reader"])
        if len(table["rows"]) != spec["expected_rows"]:
            raise ValueError("Native JSON record inventory changed")
        tables = [dict(kind="json_records", **table)]
    elif spec["kind"] == "xlsx":
        workbook = tabular.xlsx(body)
        if [table["name"] for table in workbook] != spec["sheets"]:
            raise ValueError("Native worksheet inventory changed")
        tables = [dict(kind="worksheet", **table) for table in workbook]
    elif spec["kind"] in ("xlsx_zip", "xls_zip"):
        with zipfile.ZipFile(io.BytesIO(body)) as archive:
            if sorted(archive.namelist()) != sorted(spec["members"]):
                raise ValueError("Native workbook inventory changed")
            tables = []
            for name, sheet_names in spec["members"].items():
                reader = tabular.xls if spec["kind"] == "xls_zip" else tabular.xlsx
                workbook = reader(archive.read(name))
                if [table["name"] for table in workbook] != sheet_names:
                    raise ValueError("Native worksheet inventory changed")
                tables.extend(dict(kind="worksheet", workbook=name, **table)
                    for table in workbook)
    else:
        raise ValueError("Undeclared native reader")
    return dict(contract="participation.native_factual_tables.v1",
        source={key: spec[key] for key in ("id", "url", "pin", "state_code",
            "election_year", "retrieved_at_utc", "native_updated_at", "redistribution")},
        qualification="Native facts only; no automatic geographic, turnout, or model qualification.",
        tables=tables)


def integer(value):
    if type(value) is int and value >= 0:
        return value
    if isinstance(value, str) and re.fullmatch(r"[0-9]+", value):
        return int(value)
    raise ValueError("An absent/nonapplicable/negative value is not a recorded count")


def displayed_cell(table, cells, selector):
    if isinstance(selector, str):
        return cells.get(selector, {}).get("value")
    cell = cells.get(selector["column"], {})
    value = cell.get("value")
    if value is None or isinstance(value, str):
        return value
    if selector["display"] != "excel_month_day" or type(value) is not int:
        raise ValueError("Unqualified native display conversion")
    style = int(cell["attributes"].get("s", "0"))
    number_format = table["workbook_cell_formats"][style]["numFmtId"]
    code = table["workbook_number_formats"].get(number_format)
    if code not in (r"mm\-dd", r"m\-d"):
        return value
    if value < 1:
        raise ValueError("Unqualified native month-day serial")
    date1904 = table["workbook_properties"].get("date1904", "0")
    if date1904 not in ("0", "1", "false", "true"):
        raise ValueError("Unknown native workbook date system")
    if date1904 in ("1", "true"):
        epoch = datetime(1904, 1, 1)
    else:
        if value == 60:
            raise ValueError("Fictional Excel leap day cannot be a native precinct label")
        epoch = datetime(1899, 12, 31) if value < 60 else datetime(1899, 12, 30)
    date = epoch + timedelta(days=value)
    return date.strftime("%m-%d") if code == r"mm\-dd" else f"{date.month}-{date.day}"


def query(product, spec):
    count_formats = spec.get("count_formats", {})
    if spec.get("axis", "rows") not in ("rows", "columns"):
        raise ValueError("Unreviewed native query axis")
    if (not isinstance(count_formats, dict)
            or any(field not in spec.get("counts", []) or value != "comma_grouped_integer"
                   for field, value in count_formats.items())):
        raise ValueError("An explicit supported format is required for each declared count field")
    selected = [table for table in product["tables"] if (
        spec.get("workbook") == table.get("workbook")
        and (not spec.get("tables") or table.get("name") in spec["tables"]))]
    if not selected or (spec.get("tables") and
            [table.get("name") for table in selected] != spec["tables"]):
        raise ValueError("Query table inventory differs")
    output = []
    for table in selected:
        if table["kind"] in ("delimited", "json_records"):
            if spec.get("axis") == "columns":
                raise ValueError("Column-axis queries require physical worksheet cells")
            indices = {field: tabular.column(table, label)
                for field, label in spec["fields"].items()}
            source_rows = [(row["row"], {field: row["values"][index]
                for field, index in indices.items()}) for row in table["rows"]]
        else:
            if any(spec["fields"][name] in ("$row", "$table")
                    for name in spec.get("counts", [])):
                raise ValueError("Native metadata is not a recorded count")
            for number, columns in spec.get("require", {}).items():
                actual = tabular.values(table, int(number))
                if any(actual.get(column) != expected for column, expected in columns.items()):
                    raise ValueError("Declared worksheet header changed")
            source_rows = []
            if spec.get("axis") == "columns":
                first, last = spec.get("first_column"), spec.get("last_column")
                if type(first) is not int or type(last) is not int or not 1 <= first <= last:
                    raise ValueError("An explicit physical worksheet column range is required")
                selectors = {}
                for field, selector in spec["fields"].items():
                    match = re.fullmatch(r"\$row:([1-9][0-9]*)", selector)
                    if not match and (selector != "$column" or field in spec.get("counts", [])):
                        raise ValueError("Column-axis fields require fixed native rows; metadata is not a count")
                    selectors[field] = None if selector == "$column" else tabular.values(table, int(match[1]))
                for number in range(first, last + 1):
                    index, letter = number, ""
                    while index:
                        index, remainder = divmod(index - 1, 26)
                        letter = chr(65 + remainder) + letter
                    source_rows.append((letter, {field: letter if values is None else values.get(letter)
                        for field, values in selectors.items()}))
            else:
                for row in table["rows"]:
                    if not spec.get("first_row", 1) <= row["row"] <= spec.get("last_row", float("inf")):
                        continue
                    cells = {re.sub(r"[0-9]+$", "", cell["address"]): cell for cell in row["cells"]}
                    source_rows.append((row["row"], {
                        field: (row["row"] if selector == "$row" else
                            table["name"] if selector == "$table" else
                            displayed_cell(table, cells, selector))
                        for field, selector in spec["fields"].items()}))
        for number, fields in source_rows:
            if any(fields[field] not in allowed for field, allowed in spec.get("where", {}).items()):
                continue
            if any(fields[field] in excluded for field, excluded in spec.get("exclude", {}).items()):
                continue
            for field in spec.get("counts", []):
                value = fields[field]
                if field in count_formats:
                    if not isinstance(value, str) or re.fullmatch(
                            r"(?:[0-9]+|[0-9]{1,3}(?:,[0-9]{3})+)", value) is None:
                        raise ValueError("A malformed grouped count cannot be repaired into an integer")
                    value = value.replace(",", "")
                fields[field] = integer(value)
            reference = dict(table=table.get("name"), workbook=table.get("workbook"))
            if spec.get("axis") == "columns":
                reference.update(column=number, rows_by_field={field: int(selector[5:])
                    for field, selector in spec["fields"].items() if selector.startswith("$row:")})
            else:
                reference["record_index" if table["kind"] == "json_records" else "row"] = number
            output.append(dict(**fields, source_rows=[reference]))
    keys, result = {}, []
    for row in output:
        key = tuple(row[field] for field in spec["keys"])
        if key in keys:
            if not spec.get("deduplicate"):
                raise ValueError("Repeated native query key")
            previous = keys[key]
            if {k: v for k, v in row.items() if k != "source_rows"} != {
                    k: v for k, v in previous.items() if k != "source_rows"}:
                raise ValueError("Repeated native unit disagrees")
            previous["source_rows"].extend(row["source_rows"])
        else:
            keys[key] = row
            result.append(row)
    if not result:
        raise ValueError("A declared query cannot silently become empty")
    return dict(id=spec["id"], product=spec["product"],
        count_fields=spec.get("counts", []), rows=result)


def statistical_units(source_query, spec):
    """Group explicitly reviewed native mode blocks; do not qualify their measure."""
    roles = spec["fields"]
    modes, parents = spec["modes"], spec["parents"]
    if (len(set(modes)) != len(modes) or len(set(parents)) != len(parents)
            or not modes or not parents or set(modes) & set(parents)
            or "Total" in modes + parents):
        raise ValueError("Ambiguous native mode/parent roles")
    units, current, controls, parent_modes = [], None, {}, {}
    previous_row = 0
    for row in source_query["rows"]:
        number = row[roles["row"]]
        if type(number) is not int or number <= previous_row:
            raise ValueError("Native statistical row identity changed")
        previous_row = number
        if number < spec["first_row"]:
            continue
        label = row[roles["label"]]
        values = {key: row[roles[key]] for key in ("registered", "cast", "fraction")}
        if label is None:
            if any(value not in (None, "") for value in values.values()):
                raise ValueError("An unlabeled statistical value cannot be discarded")
            continue
        if label in parents or label in modes or label == "Total":
            observation = dict(registered=integer(values["registered"]),
                cast=integer(values["cast"]), native_fraction=values["fraction"],
                source_rows=row["source_rows"])
            if label in parents:
                if current is not None or label in controls or parent_modes:
                    raise ValueError("Ambiguous native parent block")
                if controls and any(observation[key] != next(iter(controls.values()))[key]
                        for key in ("registered", "cast", "native_fraction")):
                    raise ValueError("Repeated native parent controls disagree")
                controls[label] = observation
            elif label in modes:
                target = current["modes"] if current is not None else parent_modes
                if label in target or current is None and not controls:
                    raise ValueError("Missing or repeated native mode context")
                target[label] = observation
            else:
                if current is None or controls:
                    raise ValueError("Missing native unit context")
                if (list(current["modes"]) != modes
                        or sum(v["cast"] for v in current["modes"].values()) != observation["cast"]
                        or any(v["registered"] != observation["registered"]
                            for v in current["modes"].values())):
                    raise ValueError("Native unit mode/registration controls disagree")
                current.update(observation)
                units.append(current)
                current = None
        else:
            if (current is not None or controls or not isinstance(label, str)
                    or not label.strip() or any(v not in (None, "") for v in values.values())):
                raise ValueError("Unreviewed native statistical row")
            current = dict(unit=label, header_source_rows=row["source_rows"], modes={})
    if (current is not None or not units or list(controls) != parents
            or list(parent_modes) != modes or len({u["unit"] for u in units}) != len(units)):
        raise ValueError("Incomplete or repeated native unit/parent inventory")
    parent = controls[parents[-1]]
    if (sum(u["cast"] for u in units) != parent["cast"]
            or sum(u["registered"] for u in units) != parent["registered"]
            or any(v["registered"] != parent["registered"] for v in parent_modes.values())
            or sum(v["cast"] for v in parent_modes.values()) != parent["cast"]
            or any(sum(u["modes"][mode]["cast"] for u in units) != parent_modes[mode]["cast"]
                for mode in modes)):
        raise ValueError("Native unit-to-parent controls disagree")
    return dict(units=units, parent=parent, parent_modes=parent_modes,
        agreeing_native_parent_copies=controls,
        automatic_geographic_or_turnout_qualification=False)


def compile_products(recipe, source_root, output):
    if recipe["contract"] != "participation.native_product_recipe.v1":
        raise ValueError("Unsupported native recipe")
    if output.exists():
        raise ValueError("Use a fresh output directory")
    ids = [row["id"] for row in recipe["products"]]
    query_ids = [row["id"] for row in recipe["queries"]]
    if (len(set(ids)) != len(ids) or len(set(query_ids)) != len(query_ids)
            or any(not re.fullmatch(r"[a-z0-9][a-z0-9_-]*", name) for name in ids + query_ids)):
        raise ValueError("Ambiguous or unsafe product/query identity")
    for spec in recipe["products"]:
        path = PurePosixPath(spec["path"])
        if (path.is_absolute() or ".." in path.parts or "\\" in spec["path"]
                or not (source_root / spec["path"]).resolve().is_relative_to(source_root.resolve())):
            raise ValueError("Native input must remain within the supplied source root")
        body = (source_root / spec["path"]).read_bytes()
        if pin(body) != spec["pin"]:
            raise ValueError("Changed pinned native product: " + spec["id"])
    output.mkdir(parents=True)
    products, queries = {}, {}
    for spec in recipe["products"]:
        product = unpack(spec, (source_root / spec["path"]).read_bytes())
        body = gzip.compress(encoded(product), mtime=0)
        name = spec["id"] + ".factual-tables.json.gz"
        (output / name).write_bytes(body)
        products[name] = pin(body)
        for selection in recipe["queries"]:
            if selection["product"] == spec["id"]:
                queries[selection["id"]] = query(product, selection)
    if set(queries) != set(query_ids):
        raise ValueError("A declared query refers to an absent product")
    body = encoded(dict(contract="participation.native_queries.v1", queries=queries))
    (output / "complete-queries.json").write_bytes(body)
    products["complete-queries.json"] = pin(body)
    manifest = dict(contract="participation.native_product_compilation.v1",
        recipe_pin=pin(encoded(recipe)), outputs=products,
        source_acquisitions=0, source_count_repairs=0,
        automatic_geographic_or_turnout_qualification=False)
    (output / "manifest.json").write_bytes(encoded(manifest))
    return manifest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--recipe", type=Path, required=True)
    parser.add_argument("--sources", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    result = compile_products(json.loads(args.recipe.read_bytes()), args.sources, args.output)
    print(json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
