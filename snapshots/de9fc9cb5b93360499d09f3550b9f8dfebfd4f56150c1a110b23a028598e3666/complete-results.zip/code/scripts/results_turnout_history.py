"""Read a public statewide general-election turnout series without guessing a missing year."""

import csv
from datetime import datetime
from decimal import Decimal, ROUND_HALF_UP
from html import unescape
from html.parser import HTMLParser
import io
import json
import re
from urllib.parse import urljoin
import xml.etree.ElementTree as ET

from scripts.participation_intake.contract import IntakeError, count, encoded, pin


WA_FEED = "WA-general-election-turnout"
WA_URL = ("https://www.sos.wa.gov/elections/data-research/election-data-and-maps/"
          "reports-data-and-statistics/general-election-turnout")
WA_HEADER = ("Year", "Registered Voters", "Ballots Counted", "Turnout")
WA_FIRST = 1980
VA_FEED = "VA-general-election-turnout"
VA_URL = "https://www.elections.virginia.gov/resultsreports/registrationturnout-statistics/"
VA_HEADER = ("Year", "Total Registered", "Percentage Change from Previous Year", "Total Voting",
             "Turnout (% Voting of Total Registered)", "Voting Absentee (Included in Total Voting)")
VA_TITLE = "November General Elections: 1976 \u2013 Present"
VA_CERTIFICATION = ("The Department of Elections only publishes turnout statistics for November Elections "
                    "and turnout figures are only published after the election is certified.")
VA_FIELDS = ("native_year", "registration_change_literal", "voting_absentee_literal")
TX_FEED = "TX-general-election-turnout"
TX_URL = "https://www.sos.state.tx.us/elections/historical/70-92.shtml"
TX_ARCHIVE_INPUT = "data/results-intake/tx-reviewed-turnout-history.json"
TX_ARCHIVE_PIN = {"bytes": 9746, "sha256": "94c22d392d24d2d9082b189a86a1f6b32ee2a847079aba6e65be99c3961959c5"}
TX_FIELDS = ("native_heading", "registered_literal", "voting_age_population",
             "published_registration_to_vap", "published_turnout_to_vap", "vap_rate_qualified")
TX_GENERAL = re.compile(
    r"(\d{4}) [-\u2013] (?:General|General Election,? November|November General|"
    r"(?:General, )?November \((?:Presidential|Gubernatorial)\))", re.I)
CURRENT_YEAR = 2026
KS_FEED = "KS-general-election-turnout-workbook"
KS_URL = "https://www.sos.ks.gov/elections/election-results.html"
KS_COUNTIES = {"bytes": 1737, "sha256": "a7dc594edcdb462f76861c8f1dfbc7f186b8929737c502771c7c3d264265b981"}
KS_HEADER = [["COUNTY", "ADVANCE BALLOTS", None, "TOTAL BALLOTS CAST", None, "REGISTERED"],
             [None, "RETURNED BY MAIL", None, None, None, "VOTERS"]]
NJ_FEED = "NJ-general-election-turnout-pdf"
NJ_URL = "https://www.nj.gov/state/elections/election-information-ballots-cast.shtml"
BUXTON_FEED = "ME-buxton-town-turnout"
BUXTON_URL = "https://www.buxton.me.us/news/11-3-2026-election-results"
BUXTON_TITLE = "Election Results for the Town of Buxton, Maine - November 3, 2026 State and Town Elections"
BUXTON_FIELDS = ("Registered Voters", "Absentee Ballots Cast", "Ballots Cast in Person",
                 "Total Ballots Cast", "Voter Turn Out Percent")
OH_FEED = "OH-statewide-ballots-counted"
OH_BASE = "https://liveresults.ohiosos.gov/Api/v1/"
OH_BALLOTS = OH_BASE + "Contest/getBallotsCastByCounty"
OH_ELECTION = OH_BASE + "download?filename=VSSC1622XmlFileBlob"
OH_NS = {"n": "http://grouper.ieee.org/groups/1622/groups/2/V1/1622_2-election_results_reporting.xsd"}
OH_FIELDS = ("ballotCast", "registeredVoterTotal", "reportedPrecincts", "totalPrecincts",
             "outAbsentees", "outProvisionals")
OH_XML_FIELDS = ("VotersParticipated", "VotersRegistered", "SubUnitsReported", "TotalSubUnits")
OH_COUNTY_NAMES = {"bytes": 852, "sha256": "3d981909d6bb6f7addb671c20cf9e503e51f520909781c702ca1cc2b7c06d75c"}
MT_FEED = "MT-statewide-reported-turnout"
MT_URL = "https://electionresults.mt.gov/"
MT_TITLE = "General Election - November 3, 2026"
WV_FEED = "WV-statewide-preliminary-turnout-bulletin"
WV_URL = ("https://sos.wv.gov/article/"
          "wv-secretary-state-kris-warner-announces-canvassing-will-start-monday-november-9")
WV_TITLE = "WV Secretary of State Kris Warner announces canvassing will start on Monday, November 9"
ND_CANVASS_FEED = "ND-statewide-canvass-turnout-bulletin"
ND_CANVASS_URL = "https://www.sos.nd.gov/news/state-canvassing-board-certifies-2026-general-election-results"
ND_CANVASS_TITLE = "State Canvassing Board Certifies 2026 General Election Results"
GA_FEED = "GA-statewide-county-ballots-cast"
GA_URL = "https://results.sos.ga.gov/results/public/api/elections/Georgia/11032026GeneralAndSpecialElection/data"
GA_ELECTION = "01000000-70f4-ca87-08cb-08df23e5fea8"
GA_JURISDICTION = "09378a07-e6cf-4f66-be7c-ca4aa534f99a"
GA_COUNTIES = {"bytes": 8830, "sha256": "20c0309221a8d7a606eda3f5f90f7b074241c275be772e9bafde0bf024e1ec7f"}
NJ_COUNTIES = (
    "Atlantic", "Bergen", "Burlington", "Camden", "Cape May", "Cumberland", "Essex",
    "Gloucester", "Hudson", "Hunterdon", "Mercer", "Middlesex", "Monmouth", "Morris", "Ocean",
    "Passaic", "Salem", "Somerset", "Sussex", "Union", "Warren",
)
NJ_HEADER = [
    "Total Number of Registered Voters, Ballots Cast, Ballots Rejected, Percentage of Ballots Cast and the",
    "Total Number of Election Districts in New Jersey",
    "COUNTY Total Number of Total Number of Total Number of Percent of Ballots Number of",
    "Registered Voters Ballots Cast Ballots Rejected Cast Election Districts",
]


def archive_link(body, url, pattern):
    class Links(HTMLParser):
        links = set()

        def handle_starttag(self, tag, attrs):
            if tag == "a" and (href := dict(attrs).get("href")):
                self.links.add(urljoin(url, href))

    parser = Links()
    parser.feed(body.decode("utf-8-sig"))
    links = [link for link in parser.links if re.fullmatch(pattern, link)]
    if len(links) > 1:
        raise ValueError("Ambiguous general-election turnout archive report")
    return links[0] if links else None


def kansas_link(body, year):
    return archive_link(body, KS_URL,
        rf"https://(?:www\.)?sos\.ks\.gov/elections/{year % 100:02d}elec/"
        rf"{year}-General-Election-Turnout-Information\.xlsx")


def new_jersey_report_url(year):
    return (r"https://(?:www\.)?nj\.gov/state/elections/assets/pdf/election-results/"
            rf"{year}/{year}-official-general-voter-turnout\.pdf")


def kansas_workbook(body):
    from openpyxl import load_workbook

    with io.BytesIO(body) as stream:
        workbook = load_workbook(stream, read_only=True, data_only=True)
        try:
            if len(workbook.worksheets) != 1 or workbook.active.max_column != 6 or not 110 <= workbook.active.max_row <= 150:
                raise ValueError("Kansas turnout workbook dimensions changed")
            rows = [list(row) for row in workbook.active.values]
        finally:
            workbook.close()
    if rows[:2] != KS_HEADER:
        raise ValueError("Kansas turnout workbook column labels changed")
    nonblank = [row for row in rows[2:] if any(value is not None for value in row)]
    if len(nonblank) != 106 or any(row[2] is not None or row[4] is not None for row in nonblank):
        raise ValueError("Kansas turnout workbook row inventory changed")
    counties, total = nonblank[:-1], nonblank[-1]
    query = {"counties": [[row[0], row[1], row[3], row[5]] for row in counties],
             "total": [total[1], total[3], total[5]]}
    if total[0] not in (None, "TOTAL", "STATE TOTAL"):
        raise ValueError("Kansas turnout workbook statewide selector changed")
    kansas_controls(query, allow_county_conflicts=True)
    return query


def kansas_controls(query, *, allow_county_conflicts=False):
    counties, total = query["counties"], query["total"]
    if (len(counties) != 105 or any(len(row) != 4 or not isinstance(row[0], str) for row in counties)
            or pin(encoded(sorted(row[0] for row in counties))) != KS_COUNTIES
            or len(total) != 3):
        raise ValueError("Kansas turnout county identities changed")
    for mail, ballots, registered in [row[1:] for row in counties] + [total]:
        if (type(ballots) is not int or type(registered) is not int or min(ballots, registered) < 0
                or not (mail == "N/A" or type(mail) is int and 0 <= mail <= ballots)):
            raise ValueError("Invalid Kansas turnout workbook figures")
    if (sum(row[2] for row in counties) != total[1] or sum(row[3] for row in counties) != total[2]
            or not 0 < total[1] <= total[2]):
        raise ValueError("Kansas county and statewide totals disagree")
    conflicts = [name for name, _, ballots, registered in counties if ballots > registered]
    if conflicts and not allow_county_conflicts:
        raise ValueError("Kansas county ballot counts exceed reported registrations: " + ", ".join(conflicts))
    return total[1], total[2]


def collect_kansas(collector):
    def parse(index):
        url = kansas_link(index, CURRENT_YEAR)
        if url is None:
            if (collector.prior.get(KS_FEED, {}).get("data") or {}).get("report"):
                raise ValueError("Previously reported Kansas turnout workbook is no longer linked")
            return {"current_election_status": "workbook_not_linked", "participation_observation_qualified": False}
        body, _ = collector.acquire(url)
        if len(body) > 2_000_000:
            raise ValueError("Kansas turnout workbook exceeds reviewed size bound")
        query = kansas_workbook(body)
        kansas_controls(query)
        return {"report": {"url": url, **pin(body)}, "complete_native_query": query,
                "current_election_status": "row_published", "participation_observation_qualified": False}

    return collector.capture(KS_FEED, KS_URL, parse, equivalent=lambda old, new: old == new)


def new_jersey_controls(query, election_date):
    counties, total = query["counties"], query["total"]
    if (query["election_date"] != election_date
            or query["published_date"] < election_date
            or [row["county"] for row in counties] != list(NJ_COUNTIES)
            or total["county"] != "TOTAL"):
        raise ValueError("New Jersey turnout report election or county inventory changed")
    fields = ("registered", "ballots_cast", "ballots_rejected", "election_districts")
    for row in counties + [total]:
        registered, ballots, rejected, districts = (row[field] for field in fields)
        reported = row["printed_percent"]
        if (any(type(row[field]) is not int for field in fields)
                or not registered or not 0 <= ballots <= registered
                or rejected < 0 or districts <= 0
                or type(reported) is not int
                or reported != (Decimal(ballots) * 100 / registered).quantize(
                    Decimal(1), rounding=ROUND_HALF_UP)):
            raise ValueError("New Jersey turnout report has an invalid count or printed percentage")
    if any(total[field] != sum(row[field] for row in counties) for field in fields):
        raise ValueError("New Jersey turnout report county and statewide totals disagree")
    return total["ballots_cast"], total["registered"]


def new_jersey_report(body, election_date):
    from pypdf import PdfReader

    if len(body) > 2_000_000 or not body.startswith(b"%PDF-"):
        raise ValueError("New Jersey turnout report is not a bounded PDF")
    pdf = PdfReader(io.BytesIO(body))
    if pdf.is_encrypted or len(pdf.pages) != 1:
        raise ValueError("New Jersey turnout report page inventory changed")
    lines = [" ".join(line.split()) for line in
             pdf.pages[0].extract_text(extraction_mode="layout").splitlines() if line.strip()]
    if len(lines) != 28 or lines[:2] + lines[3:5] != NJ_HEADER:
        raise ValueError("New Jersey turnout report headings or row inventory changed")
    election = datetime.strptime(lines[2], "General Election %B %d, %Y").date().isoformat()
    published = datetime.strptime(lines[-1], "NJDOE-%m/%d/%Y").date().isoformat()
    rows = []
    number = r"(?:[0-9]+|[0-9]{1,3}(?:,[0-9]{3})+)"
    for county, line in zip((*NJ_COUNTIES, "TOTAL"), lines[5:-1]):
        match = re.fullmatch(re.escape(county) + rf" ({number}) ({number}) ({number}) ([0-9]+)% ({number})",
                             line)
        if not match:
            raise ValueError("New Jersey official turnout row changed: " + county)
        values = [int(value.replace(",", "")) for value in match.groups()]
        rows.append(dict(zip(("county", "registered", "ballots_cast", "ballots_rejected",
                              "printed_percent", "election_districts"), (county, *values))))
    query = {"election_date": election, "published_date": published,
             "counties": rows[:-1], "total": rows[-1]}
    new_jersey_controls(query, election_date)
    return query


def collect_new_jersey(collector):
    def parse(index):
        url = archive_link(index, NJ_URL, new_jersey_report_url(CURRENT_YEAR))
        prior = collector.prior.get(NJ_FEED, {}).get("data") or {}
        if url is None:
            if prior.get("report"):
                raise ValueError("Previously reported New Jersey turnout PDF is no longer linked")
            return {"current_election_status": "report_not_linked", "participation_observation_qualified": False}
        body, _ = collector.acquire(url)
        query = new_jersey_report(body, "2026-11-03")
        return {"report": {"url": url, **pin(body)}, "complete_native_query": query,
                "date": query["published_date"], "current_election_status": "row_published",
                "participation_observation_qualified": False}

    return collector.capture(NJ_FEED, NJ_URL, parse, equivalent=lambda old, new: old == new)


def buxton_controls(data):
    source, query = data["report"], data["complete_native_query"]
    if (source["url"] != BUXTON_URL or type(source["bytes"]) is not int or source["bytes"] <= 0
            or not re.fullmatch(r"[a-f0-9]{64}", source["sha256"])
            or query["heading"] != BUXTON_TITLE or len(query["statistics"]) != len(BUXTON_FIELDS)):
        raise ValueError("Buxton town election identity or source receipt changed")
    values = []
    for label, line in zip(BUXTON_FIELDS, query["statistics"]):
        number = r"[0-9]+\.[0-9]{2}%" if label == BUXTON_FIELDS[-1] else r"(?:[0-9]+|[0-9]{1,3}(?:,[0-9]{3})+)"
        match = re.fullmatch(f"({number}) {label}", line)
        if not match:
            raise ValueError("Buxton town statistic missing or changed: " + label)
        values.append(match[1])
    registered, absentee, in_person, ballots = (int(value.replace(",", "")) for value in values[:-1])
    pct = values[-1]
    if (not registered or ballots > registered or absentee + in_person != ballots
            or (Decimal(ballots) * 100 / registered).quantize(
                Decimal(".01"), rounding=ROUND_HALF_UP) != Decimal(pct[:-1])):
        raise ValueError("Buxton town ballot components, register or printed rate disagree")
    return ballots, registered, pct


def buxton_report(body):
    class Blocks(HTMLParser):
        inside = False
        text = None
        tag = None

        def __init__(self):
            super().__init__()
            self.blocks = []

        def handle_starttag(self, tag, attrs):
            if tag == "article":
                self.inside = True
            if self.inside and tag in {"h2", "p"}:
                self.tag, self.text = tag, []

        def handle_data(self, text):
            if self.text is not None:
                self.text.append(text)

        def handle_endtag(self, tag):
            if tag == self.tag:
                self.blocks.append((tag, " ".join("".join(self.text).split())))
                self.tag = self.text = None
            if tag == "article":
                self.inside = False

    parser = Blocks()
    parser.feed(body.decode("utf-8-sig"))
    headings = [i for i, block in enumerate(parser.blocks) if block == ("h2", BUXTON_TITLE)]
    if len(headings) != 1:
        raise ValueError("Missing or repeated Buxton state-and-town election heading")
    start = headings[0] + 1
    fields = parser.blocks[start:start + 6]
    if not fields or fields[-1] != ("p", "State of Maine General Election") or any(
            tag != "p" for tag, _ in fields):
        raise ValueError("Buxton turnout is not in the reviewed pre-contest section")
    data = {"report": {"url": BUXTON_URL, **pin(body)}, "complete_native_query": {
        "heading": BUXTON_TITLE, "statistics": [text for _, text in fields[:-1]]}}
    buxton_controls(data)
    return data


def collect_buxton(collector):
    return collector.capture(BUXTON_FEED, BUXTON_URL, buxton_report)


def ohio_election(body):
    if len(body) > 15_000_000 or re.search(r"<!DOCTYPE|<!ENTITY", body.decode("utf-8-sig"), re.I):
        raise ValueError("Ohio election XML exceeds reviewed document bounds")
    root = ET.fromstring(body)
    elections = root.findall("n:Election", OH_NS)
    if len(elections) != 1 or elections[0].attrib != {"Date": "2026-11-03", "Type": "General"}:
        raise ValueError("Ohio election XML does not declare the November 2026 general election")
    title = elections[0].findtext("n:Name/n:LanguageString", namespaces=OH_NS)
    clock = root.get("GeneratedDate")
    status = root.get("Status")
    if (root.tag != f"{{{OH_NS['n']}}}ElectionReport"
            or root.get("IssuerAbbreviation") != "OH"
            or status not in {"UnofficialComplete", "UnofficialPartial"}
            or title != "November 3, 2026 General Unofficial Canvass"
            or not re.fullmatch(r"202[67]-\d\d-\d\dT\d\d:\d\d:\d\dZ", clock or "")
            or datetime.strptime(clock, "%Y-%m-%dT%H:%M:%SZ").date().isoformat() < "2026-11-03"):
        raise ValueError("Ohio election XML issuer, status or report clock changed")
    rows = [[unit.get("ObjectId"), unit.get("Name"),
             *[integer(unit.get(field, "")) for field in OH_XML_FIELDS]]
            for unit in root.findall("n:GpUnitCollection/n:GpUnit", OH_NS)
            if unit.get("Type") == "County" and unit.get("IsElectoralDistrict") == "false"]
    return {"source": {"url": OH_ELECTION, **pin(body)}, "date": "2026-11-03",
            "title": title, "status": status, "generated_at": clock, "counties": rows}


def ohio_controls(query):
    rows, total, control = query["counties"], query["total"], query["election"]
    derived = query.get("basis") == "dated_xml_county_sum"
    if (len(rows) != 88 or len({row[0] for row in rows}) != 88
            or any(not isinstance(row[1], str) for row in rows)
            or pin(encoded(sorted(row[1] for row in rows))) != OH_COUNTY_NAMES
            or total[:2] != [None, "County sum" if derived else "Totals"] or len(total) != 9
            or len(control["counties"]) != 88
            or control["source"]["url"] != OH_ELECTION or control["source"]["bytes"] <= 0
            or not re.fullmatch(r"[a-f0-9]{64}", control["source"]["sha256"])
            or control["date"] != "2026-11-03"
            or control["title"] != "November 3, 2026 General Unofficial Canvass"
            or control["status"] not in {"UnofficialComplete", "UnofficialPartial"}
            or sorted(row[:6] for row in rows) != sorted(control["counties"])):
        raise ValueError("Ohio ballot county frame is not reconciled to its dated XML")
    for row in rows + [total]:
        ballots, registered, reported, units, absentee, provisional = row[2:8]
        if (len(row) != 9 or any(type(n) is not int or n < 0 for n in row[2:6])
                or not registered or ballots > registered or not 0 <= reported <= units
                or (derived and (absentee, provisional, row[8]) != (None, None, None))
                or (not derived and (any(type(n) is not int or n < 0 for n in (absentee, provisional))
                    or not re.fullmatch(r"[0-9]+\.[0-9]{2}", row[8])
                    or (Decimal(ballots) * 100 / registered).quantize(
                        Decimal(".01"), rounding=ROUND_HALF_UP) != Decimal(row[8])))):
            raise ValueError("Ohio turnout count, denominator or reported fraction changed")
    stop = 6 if derived else 8
    if [sum(row[n] for row in rows) for n in range(2, stop)] != total[2:stop]:
        raise ValueError("Ohio county totals do not reconcile to the printed statewide rows")
    return total[2], total[3]


def ohio_ballots(body, control):
    entries = json.loads(body)
    if len(entries) != 90:
        raise ValueError("Ohio ballot table inventory changed")
    rows = [[entry["objectId"], entry["name"],
             *[integer(entry[field]) for field in OH_FIELDS], entry["ballotCastPercent"]]
            for entry in entries]
    if rows[0] != rows[-1]:
        raise ValueError("Ohio's two printed statewide totals disagree")
    query = {"counties": rows[1:-1], "total": rows[0], "election": control}
    ohio_controls(query)
    return query


def collect_ohio(collector):
    def parse_xml(body):
        control = ohio_election(body)
        rows = [row + [None, None, None] for row in control["counties"]]
        total = [None, "County sum", *[sum(row[i] for row in rows) for i in range(2, 6)],
                 None, None, None]
        query = {"basis": "dated_xml_county_sum", "counties": rows, "total": total, "election": control}
        ohio_controls(query)
        return {"report": control["source"], "complete_native_query": query,
                "date": control["generated_at"], "participation_observation_qualified": False}

    def stopped():
        try:
            collector.guard(OH_BALLOTS)
        except IntakeError as error:
            if error.code == "source_stopped":
                return True
            raise
        return False

    def parse(body):
        control, _ = collector.acquire(OH_ELECTION)
        query = ohio_ballots(body, ohio_election(control))
        return {"report": {"url": OH_BALLOTS, **pin(body)}, "complete_native_query": query,
                "date": query["election"]["generated_at"], "participation_observation_qualified": False}

    previous = collector.prior.get(OH_FEED) or {}
    keep_direct = (previous.get("source") or {}).get("url") == OH_BALLOTS
    if stopped() and not keep_direct:
        return collector.capture(OH_FEED, OH_ELECTION, parse_xml)
    result = collector.capture(OH_FEED, OH_BALLOTS, parse)
    if not keep_direct and result["status"] != "reported" and stopped():
        return collector.capture(OH_FEED, OH_ELECTION, parse_xml)
    return result


def montana_controls(query):
    turnout, registered = query["total_turnout"], query["registered_voters"]
    fully, partial, missing = query["precincts"]
    printed = query["printed_rate"]
    clock = datetime.strptime(query["clock"], "%m/%d/%Y %I:%M:%S %p MT")
    if (query["election"] != MT_TITLE or clock.date().isoformat() < "2026-11-03"
            or any(type(n) is not int or n < 0 for n in (turnout, registered, fully, partial, missing))
            or not 0 <= turnout <= registered or not registered or not fully + partial + missing
            or turnout != query["chart_turnout"] or registered - turnout != query["chart_remainder"]
            or not re.fullmatch(r"[0-9]+\.[0-9]{2}%", printed)
            or (Decimal(turnout) * 100 / registered).quantize(
                Decimal(".01"), rounding=ROUND_HALF_UP) != Decimal(printed[:-1])
            or (Decimal(fully) * 100 / (fully + partial + missing)).quantize(
                Decimal(".01"), rounding=ROUND_HALF_UP) != Decimal(query["precinct_rate"][:-1])):
        raise ValueError("Montana statewide election, turnout or reporting fields do not reconcile")
    return turnout, registered, clock


def montana_report(body):
    html = body.decode("utf-8-sig")

    def fields(pattern):
        hits = re.findall(pattern, html)
        if len(hits) != 1:
            raise ValueError("Missing or repeated Montana statewide report field")
        return hits[0]

    election = fields(r"<h2>(General Election - [^<]+)</h2>")
    turnout, registered = fields(
        r"<h2>Total Turnout <span>([\d,]+)</span><br\s*/>\s*Registered Voters <span[^>]*>([\d,]+)</span></h2>")
    chart = r"<canvas id=\"{}\" {}></canvas><div class=\"dough-percent\">"
    rate = r'<span class="int">(\d+)</span><span class="dec">(\.\d{{2}}%)</span>'
    desktop, remainder, pct, decimal = fields((chart + rate).format(
        "voter-turnout", r"voterturnout='(\d+)' votertotal='(\d+)'"))
    fully, partial, missing, ppct, pdecimal = fields((chart + rate).format(
        "precinct-reported", r"precinctsreported='(\d+)' precinctspartial='(\d+)' precinctsnotreported='(\d+)'"))
    printed_partial, printed_fully = fields(
        r"Partially <span[^>]*>([\d,]+)</span><br/>\s*<div[^>]*></div>Fully <span>([\d,]+)</span>")
    if (integer(printed_partial), integer(printed_fully)) != (int(partial), int(fully)):
        raise ValueError("Montana printed precinct counts differ from the chart")
    query = {"election": election, "total_turnout": integer(turnout), "registered_voters": integer(registered),
             "chart_turnout": int(desktop), "chart_remainder": int(remainder), "printed_rate": pct + decimal,
             "clock": fields(r"Results last updated:\s*([0-9/]+ [0-9:]+ [AP]M MT)"),
             "precincts": [int(fully), int(partial), int(missing)], "precinct_rate": ppct + pdecimal}
    _, _, clock = montana_controls(query)
    return {"report": {"url": MT_URL, **pin(body)}, "complete_native_query": query,
            "date": clock.isoformat(), "participation_observation_qualified": False}


def collect_montana(collector):
    return collector.capture(MT_FEED, MT_URL, montana_report,
                             equivalent=lambda old, new: old["complete_native_query"] == new["complete_native_query"])


def west_virginia_controls(query):
    if (set(query) != {"title", "publication_date", "turnout_passage"}
            or query["title"] != WV_TITLE or query["publication_date"] != "2026-11-06"):
        raise ValueError("West Virginia preliminary bulletin identity changed")
    match = re.fullmatch(
        r"Preliminary turnout totals for West Virginia's November 3 General Election show that "
        r"([\d,]+) ballots were cast statewide, representing (\d{1,3}\.\d{2}%) of "
        r"West Virgin(?:i)?a's ([\d,]+) registered voters\.", query["turnout_passage"])
    if match is None:
        raise ValueError("Missing or incompatible West Virginia statewide turnout passage")
    ballot_literal, printed, registration_literal = match.groups()
    ballots, registered = integer(ballot_literal), integer(registration_literal)
    if not 0 < ballots <= registered or (Decimal(ballots) * 100 / registered).quantize(
            Decimal(".01"), rounding=ROUND_HALF_UP) != Decimal(printed[:-1]):
        raise ValueError("West Virginia ballot counts and registration fraction do not reconcile")
    return ballots, registered, printed


def west_virginia_report(body):
    text = body.decode("utf-8-sig")
    titles = re.findall(r"<h1\b[^>]*><span>([^<>]+)</span></h1>", text)
    dates = re.findall(r'<time\s+datetime="(\d{4}-\d\d-\d\d)T[^"]+">November 6, 2026</time>', text)
    passages = re.findall(r"<p>(Preliminary turnout totals for West Virginia's November 3 General Election "
                          r"show that .*? registered voters\.)", text, re.S)
    if len(titles) != 1 or len(dates) != 1 or len(passages) != 1:
        raise ValueError("Missing or repeated West Virginia ballot bulletin fields")
    passage = " ".join(unescape(re.sub(r"</?a\b[^>]*>", "", passages[0])).split())
    query = {"title": titles[0], "publication_date": dates[0], "turnout_passage": passage}
    west_virginia_controls(query)
    return {"report": {"url": WV_URL, **pin(body)}, "complete_native_query": query,
            "date": dates[0], "participation_observation_qualified": False}


def collect_west_virginia(collector):
    return collector.capture(WV_FEED, WV_URL, west_virginia_report,
                             equivalent=lambda old, new: old["complete_native_query"] == new["complete_native_query"])


def north_dakota_canvass_controls(query):
    if (set(query) != {"title", "publication_date", "voters_cast_ballots", "printed_pct"}
            or query["title"] != ND_CANVASS_TITLE or query["publication_date"] != "2026-11-18"
            or not re.fullmatch(r"\d{1,3}\.\d%", query["printed_pct"])):
        raise ValueError("North Dakota canvass bulletin scope changed")
    voters = integer(query["voters_cast_ballots"])
    if not voters or not 0 < Decimal(query["printed_pct"][:-1]) <= 100:
        raise ValueError("Invalid North Dakota canvass turnout")
    return voters, query["printed_pct"]


def north_dakota_canvass_report(body):
    text = body.decode("utf-8-sig")
    titles = re.findall(r"<h1\b[^>]*>([^<>]+)</h1>", text)
    dates = re.findall(r'<time class="news-date" datetime="(\d{4}-\d\d-\d\d)T[^"]+">', text)
    totals = re.findall(
        r"<p>In the 2026 General Election,\s*([\d,]+) eligible voters cast ballots "
        r"for a statewide voter turnout of (\d{1,3}\.\d%)\.</p>", text)
    if len(titles) != 1 or len(dates) != 1 or len(totals) != 1:
        raise ValueError("Missing or repeated North Dakota canvass turnout fields")
    voters, printed = totals[0]
    query = {"title": titles[0], "publication_date": dates[0],
             "voters_cast_ballots": voters, "printed_pct": printed}
    north_dakota_canvass_controls(query)
    return {"report": {"url": ND_CANVASS_URL, **pin(body)}, "complete_native_query": query,
            "date": dates[0], "participation_observation_qualified": False}


def collect_north_dakota_canvass(collector):
    return collector.capture(
        ND_CANVASS_FEED, ND_CANVASS_URL, north_dakota_canvass_report,
        equivalent=lambda old, new: old["complete_native_query"] == new["complete_native_query"])


def georgia_edition(value):
    if not isinstance(value, str) or not re.fullmatch(r"202[67]-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.\d{1,7})?Z", value):
        raise ValueError("Invalid Georgia publication or county timestamp")
    whole, _, fraction = value[:-1].partition(".")
    parsed = datetime.fromisoformat(whole)
    if not datetime(2026, 11, 3) <= parsed < datetime(2027, 2, 1):
        raise ValueError("Georgia timestamp outside the 2026 general-election window")
    return whole + "." + fraction.ljust(7, "0") + "Z"


def georgia_controls(query):
    rows = query["counties"]
    georgia_edition(query["published"])
    if (query["election_id"] != GA_ELECTION or query["jurisdiction_id"] != GA_JURISDICTION
            or query["election_date"] != "2026-11-03" or type(query["official"]) is not bool
            or len(rows) != 159 or pin(encoded({row["id"]: row["name"] for row in rows})) != GA_COUNTIES):
        raise ValueError("Georgia election scope or county inventory changed")
    for row in rows:
        ballots, registered = row["ballots"], row["registered"]
        if (type(ballots) is not int or type(registered) is not int or not 0 < ballots <= registered
                or type(row["official"]) is not bool
                or not re.fullmatch(r"[a-f0-9-]{36}", row["election_id"])
                or type(row["precincts_reporting"]) not in (int, float)
                or not 0 <= row["precincts_reporting"] <= 1):
            raise ValueError("Missing or invalid Georgia county turnout fields")
        if georgia_edition(row["updated"]) > georgia_edition(query["published"]):
            raise ValueError("Georgia county count postdates its statewide publication")
    ballots = sum(row["ballots"] for row in rows)
    registered = sum(row["registered"] for row in rows)
    if (len({row["election_id"] for row in rows}) != 159 or query["state_registered"] != registered
            or query["state_ballots"] not in (0, ballots)):
        raise ValueError("Georgia statewide and county reporting frames disagree")
    return ballots, registered


def georgia_report(body):
    if len(body) > 10_000_000:
        raise ValueError("Georgia bulk results exceed reviewed document bounds")
    document = json.loads(body)
    election, jurisdiction = document["election"], document["jurisdiction"]

    def name(row, field):
        text, = (label["text"] for label in row[field] if label["languageId"] == "en")
        return text

    def indexed(rows, field):
        result = {row[field].lower(): row for row in rows}
        if len(result) != len(rows):
            raise ValueError("Duplicate Georgia county identity")
        return result

    def total(value):
        if type(value) not in (int, float) or not 0 <= value <= 20_000_000 or int(value) != value:
            raise ValueError("Georgia counts must be nonnegative whole numbers")
        return int(value)

    if (name(jurisdiction, "name") != "Georgia" or jurisdiction["id"] != GA_JURISDICTION
            or name(election, "name") != "November 3, 2026 - General & Special Elections"
            or election["isPrimary"] is not False or election["isProduction"] is not True):
        raise ValueError("Georgia feed does not declare reviewed production general election")
    localities = indexed(jurisdiction["childLocalities"], "id")
    results = indexed(document["localityElections"], "jurisdictionId")
    registrations = indexed(document["voterRegistration"], "id")
    if set(localities) != set(results) or set(localities) != set(registrations):
        raise ValueError("Georgia county results, registrations and localities differ")
    rows = []
    for key in sorted(localities):
        local, result, registration = localities[key], results[key], registrations[key]
        county = name(local, "name")
        registered = total(result["totalVoters"])
        if (name(registration, "localityName") != county or total(registration["total"]) != registered
                or result["electionDate"] != election["electionDate"]
                or name(result, "name") != name(election, "name")
                or result["isPrimary"] is not False or result["isProduction"] is not True):
            raise ValueError("Georgia county count and registration evidence disagree")
        rows.append({"id": key, "name": county, "election_id": result["id"],
                     "ballots": total(result["ballotsCast"]), "registered": registered,
                     "updated": result["lastUpdated"], "official": result["isOfficialResults"],
                     "precincts_reporting": result["precinctsReporting"]})
    query = {"election_id": election["id"], "election_date": election["electionDate"],
             "jurisdiction_id": election["jurisdictionId"], "published": election["publishDate"],
             "official": election["isOfficialResults"], "state_ballots": total(election["ballotsCast"]),
             "state_registered": total(election["totalVoters"]), "counties": rows}
    georgia_controls(query)
    return {"report": {"url": GA_URL, **pin(body)}, "complete_native_query": query,
            "date": georgia_edition(query["published"]),
            "participation_observation_qualified": False}


def collect_georgia(collector):
    return collector.capture(GA_FEED, GA_URL, georgia_report,
                             equivalent=lambda old, new: old["complete_native_query"] == new["complete_native_query"])


def integer(value):
    if not re.fullmatch(r"[0-9]+|[0-9]{1,3}(?:,[0-9]{3})+", value):
        raise ValueError("Turnout table needs literal integer counts")
    return count(value.replace(",", ""))


def table_rows(rows, first, last):
    result = []
    for cells in rows:
        if len(cells) != 4 or not re.fullmatch(r"[0-9]{4}", cells[0]) or not re.fullmatch(
                r"[0-9]{1,3}(?:\.[0-9]{1,2})?%", cells[3]):
            raise ValueError("Turnout table row schema changed")
        year, registered, ballots, printed = int(cells[0]), integer(cells[1]), integer(cells[2]), cells[3]
        if registered is None or ballots is None or not 0 <= ballots <= registered or not registered:
            raise ValueError("Turnout table count is missing or outside its register")
        digits = len(printed.partition(".")[2].removesuffix("%"))
        period = Decimal(1).scaleb(-digits)
        rounded = (Decimal(ballots) * 100 / registered).quantize(period, rounding=ROUND_HALF_UP)
        result.append({"year": year, "registered_voters": registered, "ballots_counted": ballots,
                       "published_turnout": printed, "rate_qualified": rounded == Decimal(printed[:-1])})
    years = [r["year"] for r in result]
    if years not in (list(range(last, first - 1, -1)), list(range(last - 1, first - 1, -1))):
        raise ValueError("Unexpected election-year inventory; missing years are never zero")
    return result


def html_tables(body):
    from scripts.results_granular import FactualHTMLTables

    parser = FactualHTMLTables()
    parser.feed(body.decode("utf-8-sig"))
    return [[tuple(" ".join(cell["value"].split()) for cell in row["cells"]) for row in table["rows"]]
            for table in parser.tables]


def parse_washington(body):
    candidates = [rows[1:] for rows in html_tables(body) if rows and rows[0] == WA_HEADER]
    if len(candidates) != 1:
        raise ValueError("Missing or ambiguous Washington general-election turnout table")
    facts = table_rows(candidates[0], WA_FIRST, CURRENT_YEAR)
    return history_query(facts)


def parse_virginia(body):
    tables = [rows[2:] for rows in html_tables(body) if rows[:2] == [(VA_TITLE,), VA_HEADER]]
    notes = [" ".join(unescape(text).split()) for text in re.findall(
        r"<p>(\*[^<]+|The Department of Elections only publishes turnout statistics[^<]+)</p>",
        body.decode("utf-8-sig"))]
    if len(tables) != 1 or len(notes) != 4 or notes[0] != VA_CERTIFICATION:
        raise ValueError("Virginia November election table, certification policy or footnotes changed")
    native = tables[0]
    for row in native:
        if (len(row) != 6 or not re.fullmatch(r"[0-9]{4}\*?", row[0])
                or "*" in row[0] and row[0] != "1996*"):
            raise ValueError("Virginia November election row schema changed")
    facts = table_rows([(year.rstrip("*"), register, voting, rate)
                        for year, register, _, voting, rate, _ in native], 1976, CURRENT_YEAR)
    for row, (year, _, change, _, _, absentee) in zip(facts, native):
        if absentee != "***" and not 0 <= integer(absentee) <= row["ballots_counted"]:
            raise ValueError("Virginia absentee count is incompatible with Total Voting")
        row.update(zip(VA_FIELDS, (year, change, absentee)))
    query = history_query(facts)
    for row in facts:
        row["total_voting"] = row.pop("ballots_counted")
    return {**query, "native_measure": "Total Voting", "published_after_certification": True,
            "registered_includes": ["active", "inactive", "overseas"],
            "historical_qualifications": ["Virginia implemented NVRA in March 1996.",
                "** marks earlier roll purges; *** marks no separately reported absentee total."]}


def parse_texas(body):
    def printed(literal, numerator, denominator):
        if not re.fullmatch(r"[0-9]{1,3}(?:\.[0-9]{1,2})?%?", literal):
            raise ValueError("Invalid Texas printed turnout fraction")
        number = Decimal(literal.rstrip("%"))
        period = Decimal(1).scaleb(number.as_tuple().exponent)
        return (Decimal(numerator) * 100 / denominator).quantize(
            period, rounding=ROUND_HALF_UP) == number

    tables = [table for table in html_tables(body) if any(len(row) == 1 and TX_GENERAL.fullmatch(row[0])
                                                          for row in table)]
    if len(tables) != 1:
        raise ValueError("Missing or ambiguous Texas election turnout table")
    table, = tables
    labels = ("Registered Voters", "Voting Age Population (VAP)", "Percentage of VAP Registered",
              "Turnout", "Percent of Turnout to Registered", "Percent of Turnout to VAP")
    facts = []
    for offset, heading in enumerate(table):
        match = TX_GENERAL.fullmatch(heading[0]) if len(heading) == 1 else None
        if not match:
            continue
        fields = table[offset + 1:offset + 7]
        if (len(fields) != 6 or any(len(row) != 2 for row in fields)
                or tuple(key.removesuffix(" Voters") if key.startswith("Percent of Turnout to Registered")
                         else key for key, _ in fields) != labels):
            raise ValueError("Texas election turnout field labels changed")
        register, vap, reg_pct, turnout, turnout_pct, vap_pct = (value for _, value in fields)
        year = int(match[1])
        registered, population, reported = integer(register.rstrip("*")), integer(vap), integer(turnout)
        if (not registered or not population or not reported
                or not reported <= min(registered, population)
                or year == CURRENT_YEAR and register.endswith("*")):
            raise ValueError("Texas election turnout counts do not fit their denominators")
        rate = printed(turnout_pct, reported, registered) and not register.endswith("*")
        vap_rate = printed(vap_pct, reported, population)
        facts.append({"year": year, "registered_voters": registered, "total_voting": reported,
                      "published_turnout": turnout_pct, "rate_qualified": rate,
                      **dict(zip(TX_FIELDS, (heading[0], register, population, reg_pct, vap_pct, vap_rate)))})
    expected = list(range(2024, 1969, -2))
    if [row["year"] for row in facts] not in (expected, [CURRENT_YEAR, *expected]):
        raise ValueError("Texas November general-election inventory changed")
    return {"complete_native_query": facts, "native_measure": "Turnout",
            "current_election_status": "row_published" if facts[0]["year"] == CURRENT_YEAR else "not_yet_published",
            "participation_observation_qualified": False}


def history_query(facts):
    if facts[0]["year"] == CURRENT_YEAR and not facts[0]["ballots_counted"]:
        raise ValueError("Current statewide count must be positive")
    return {"complete_native_query": facts,
            "current_election_status": "row_published" if facts[0]["year"] == CURRENT_YEAR else "not_yet_published",
            "participation_observation_qualified": False}


def collect_history(collector, feed, url, parser):
    def parse(body):
        data = parser(body)
        previous = (collector.prior.get(feed) or {}).get("data") or {}
        if (previous.get("current_election_status") == "row_published"
                and data["current_election_status"] != "row_published"):
            raise ValueError("Previously published general-election row is missing")
        return data

    return collector.capture(feed, url, parse, equivalent=lambda old, new: old == new)


def collect_washington(collector):
    return collect_history(collector, WA_FEED, WA_URL, parse_washington)


def collect_virginia(collector):
    return collect_history(collector, VA_FEED, VA_URL, parse_virginia)


def collect_texas(collector):
    return collect_history(collector, TX_FEED, TX_URL, parse_texas)


def texas_history_entry(entry, retained_archive):
    if entry.get("data") or retained_archive is None:
        return entry
    if pin(retained_archive) != TX_ARCHIVE_PIN:
        raise ValueError("Texas retained turnout archive checksum differs")
    data = json.loads(retained_archive)
    source = data.pop("source")
    if (source["url"] != TX_URL or data["current_election_status"] != "not_yet_published"
            or data["native_measure"] != "Turnout"
            or [row["year"] for row in data["complete_native_query"]] != list(range(2024, 1969, -2))):
        raise ValueError("Texas retained turnout archive scope differs")
    data["latest_attempt_status"] = entry.get("status", "not_reported")
    return {"status": "retained_after_failure", "source": source, "data": data}


def history_csv(entry, *, virginia=False, texas=False):
    out = io.StringIO(newline="")
    count_field = "total_voting" if virginia or texas else "ballots_counted"
    columns = ("year", "registered_voters", count_field, "published_turnout", "rate_qualified")
    columns += (VA_FIELDS if virginia else TX_FIELDS if texas else ()) + ("publication_status", "source_url", "source_sha256")
    writer = csv.DictWriter(out, fieldnames=columns, lineterminator="\n")
    writer.writeheader()
    for row in entry["data"]["complete_native_query"]:
        writer.writerow({**row, "publication_status": entry["status"],
                         "source_url": entry["source"]["url"], "source_sha256": entry["source"]["sha256"]})
    return out.getvalue().encode()


def washington_csv(entry):
    return history_csv(entry)
