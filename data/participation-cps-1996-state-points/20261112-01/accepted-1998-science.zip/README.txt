COMPLETE 1998 NATIVE STATE DEMOGRAPHIC PARTICIPATION POINTS

468 source rows / 4680 literal metric cells across all51states/DC plusUS,
nine native groups and1404 metric decisions. 1060 reported points selected;
343(B) measures and one invalid900. citizenship percentage remain withheld.
NewMexico's printed0.8. standard error stays literal and uninterpreted.
1059 printed source SEs are retained, including ten literal zeros. No newCIs.
32 literal dot counts are not converted to zero;14 actual zero counts survive.

Native counts are rounded thousands, NOT sampleN or exact persons. Registered
and voted percentages use the source adult18+ population, NOT citizens.
Citizenship percentage is a population share, not participation or eligibility.
No suppressed measure is recovered from counts. Source defects are not repaired.
Native groups overlap; N-H means Non-Hispanic, API includes Asian/PacificIslander,
and Hispanic may be any race. Neither a modern race alias nor a group partition.

All936 1998-to-2002 group/metric decisions (675 compatible source-label snapshots,
104 non-HispanicAPI/allAPI holds plus native source holds); all104 original vs
retrospective decisions (102 match, twoUS absences), and208 2018/2022 same-VAP
overall decisions (204 descriptive comparisons/fourUS absences) are included.
These are repeated source snapshots, NOT harmonized definitions, cohorts,
individual retention, observed staying home or significant changes. 1998 SEs
are not applied to2002 confidence scalars or converted to change intervals.

The new Census native directory and separately declared TXT were acquired once;
the denied HTML landing page remains stopped. No alternate client/cache/mirror
recovered that page. Full TXT plus all permitted policy/provenance, ENTIRE accepted
1241697-byte 2002 science ZIP (including original XLS/PDFs and older science),
maintained code/tests and EVERY complete result/query are included. No publisher
HTML/app code, session headers, private respondent identifiers or survey fine cells.

Python3.9+ standard library only. Reproduce in a fresh extracted packet:
python3 -Werror code/scripts/reproduce_cps_1998_state_points.py --package . --output /fresh/path
Seven tests, all independent checks and every result/query byte run with network
and external commands blocked. Earlier source acquisitions/reductions are not rerun.
No new frontend activation, model refit, population validation or local allocation.
