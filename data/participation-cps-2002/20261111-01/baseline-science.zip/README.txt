Complete native CPS state voting/registration percentages and separate AP diagnostics.
All sufficient originals/caches, original voter query, complete outputs, code and tests included.
Read summary.json: these ratios are not administrative or joint registered-voter turnout.
python3 -m unittest discover -s tests -p test_cps_state_frames.py
python3 -m scripts.cps_state_frames --inputs inputs --output reproduced
