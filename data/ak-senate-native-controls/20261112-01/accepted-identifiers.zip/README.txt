Source-missing Senate county identifier joins, not native declarations or outcome validation.
All original candidate-unit fields/counts/clocks remain unchanged in the complete query.
From the unpacked complete archive, without packages/network:
  python3 -m unittest discover -s tests -p test_senate_geography.py
  python3 -m scripts.senate_geography --native-query inputs/native-query.csv --house-counties inputs/house-counties.json.gz --state-codes inputs/state-codes.json --output reproduced
Held Census-backed House namespace IDs and CNN declared IDs support geography.
Matching candidate identities do not mean equal counts, matched rounds or independent validation.
Maine write-ins and all earlier unmatched control scopes remain unresolved.
