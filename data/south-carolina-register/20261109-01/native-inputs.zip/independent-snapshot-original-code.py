from datetime import datetime
from decimal import Decimal
import hashlib
import json
from pathlib import Path

import openpyxl


FILES = Path(__file__).parent
ORIGINAL = FILES / "south-carolina-west-virginia-acquisition-01/registration.xlsx"
OUTPUT = FILES / "south-carolina-native-cells-01"
assert not OUTPUT.exists()
assert hashlib.sha256(ORIGINAL.read_bytes()).hexdigest() == "04067e0bacdbc0b9e04d41e4f088d6a1371ceeb821fb2d3cc4a1e1b9f5271b7b"
book = openpyxl.load_workbook(ORIGINAL, read_only=True, data_only=True)
cells, dimensions = [], {}
for sheet in book:
    native_rows = list(sheet.iter_rows())
    columns = max(len(row) for row in native_rows)
    dimensions[sheet.title] = dict(rows=len(native_rows), columns=columns)
    for row_number, row in enumerate(native_rows, 1):
        for column in range(1, columns + 1):
            source = row[column - 1] if column <= len(row) else None
            value = source.value if source is not None else None
            kind = "blank"
            if isinstance(value, datetime):
                kind, value = "datetime", value.isoformat()
            elif isinstance(value, str):
                kind = "text"
            elif value is not None:
                kind, value = "number", format(Decimal(str(value)).normalize(), "f")
            address = openpyxl.utils.get_column_letter(column) + str(row_number)
            cells.append(dict(sheet=sheet.title, cell=address, kind=kind, value=value))
book.close()
OUTPUT.mkdir()
body = (json.dumps(cells, indent=2) + "\n").encode()
(OUTPUT / "openpyxl-cells.json").write_bytes(body)
receipt = dict(workbook_sha256=hashlib.sha256(ORIGINAL.read_bytes()).hexdigest(),
               openpyxl_version=openpyxl.__version__, canonical_cells=len(cells), dimensions=dimensions,
               snapshot_sha256=hashlib.sha256(body).hexdigest(),
               absent_rectangular_positions_are_blank_not_numeric_zero=True,
               full_stdlib_xml_comparison_and_population_scope_qualification_pending=True)
(OUTPUT / "extraction-receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps(receipt, indent=2))
