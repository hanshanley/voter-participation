COMPLETE REPORTED 2002 CPS POINT-SELECTION SCIENCE

693 selected native table rows, 642 distinct geography/frame/category cells,
including 540 non-total group rows. Duplicate total rows and overlapping groups
are not independent or additive. All832rows/8320metric cells and every hold remain.
Sex/race/age rates use ALL ADULTS; only the separate overall table uses citizens.
Race labels are exact historical source labels, not harmonized modern categories.
131 missing/suppressed rows, six defect rows and all3PA conflicting totals are held.
The 75,000-person caution uses weighted population, NOT sample size or precision.
Native confidence scalars are uninterpreted; no SEs or CIs are calculated.
Only the directly printed national citizen interval is retained as a report fact.
100 supported 2002-to-2018/2022 midterm citizen-overall snapshot differences,
all104 snapshot decisions and832source reconciliation decisions are included.
No significance, cohort transition, 2026 estimate, administrative staying home,
population validation, repaired count, racial harmonization or local allocation.

Includes all3original XLS files, both full official PDFs, complete accepted factual
and methodological reductions, the ENTIRE accepted historical-frame science ZIP,
all new inputs/code/tests/results/queries. No acquisition session headers or HTML apps.
Requires only Python3.9+; no dependencies, original parsing, acquisition or installation.
Reproduce: python3 code/scripts/reproduce_cps_2002_selection.py --package . --output /fresh/path
The reproducer blocks network/external commands, runs10focused tests and the independent
verifier, and compares every full result/query byte. No frontend or live data activation.
