COMPLETE RETURN-CONSTRAINED TRANSITION SCENARIOS

113state/office decisions;89 compatible reported comparisons;24unavailable.
All801fitted scenarios,12816synthetic transition cells,678endpoint decisions,
113selection decisions, all native D/R counts and available Other counts,
full viewer/results/code/tests and BOTH ENTIRE previous science archives.
No metadata-only download, private respondents or reconstructed source joints.

This is NEW endpoint calibration, NOT proof of individual voter histories.
The old survey-recall baseline is a transition PRIOR, not the observed
same-office baseline. Both D/R endpoint counts constrain nonnegative cells.
A relative-entropy matrix projection chooses one table, not a unique truth.
Four Shapley mechanisms include denominator effects and sum exactly to the
observed normalized margin. Independent24ordering verification covers all801.
There is no ad-hoc Other/unallocated balancing term.

Common frame size is ASSUMED from the source prior's current known-party
weight, not measured population. Vary it0.8/1/1.25 and prior persistence
0.5/1/2 for nine cases. Lower frame bounds are explicit. Original synthetic
N/U are pooled only in the prior. No counted candidate vote does NOT
establish no ballot, new eligibility, deaths, migration or first-ever voting.
Other totals absent from governor frames stay absent in NATIVE inputs;
their synthetic split uses the prior and is labeled assumed, not observed0.
Reported source snapshots/footprints/competition caveats remain. No state
model is allocated to counties/precincts. No confidence/identification interval
or independent behavioral validation is claimed. Old estimates are archived.

Reproduce NEW fits without network/external commands or old source refits:
python3 -Werror code/scripts/reproduce_calibrated_swing.py --package . --output /fresh/path
Reference byte-identical toolchain Python3.9; later Python versions may differ
in floating summation/serialization. The model and independent endpoint/
permutation verifier use only the standard library.
