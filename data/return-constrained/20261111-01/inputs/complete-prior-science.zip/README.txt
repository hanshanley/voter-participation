Conditional source-frame scenarios, not validated population histories.
See docs/TRANSITION_SIMULATION.md. All sufficient permitted inputs, code,
queries, scenarios, seeds, disclosure holds and validation decisions included.
Run: python scripts/reproduce_transition_simulation.py --archive complete-analysis.zip --output reproduction.json
