Coarse historical state AP/NORC VoteCast model shares: 2018/2020/2022/2024.
Registered survey source frames, NOT administrative demographic turnout.
Poll-close/final state weights are separate views of the same sample, not independent samples.
2018 state rows are descriptive: publisher reports 47 inference states despite all 50 sampled.
2022 DE/WV state inference is held. RACETH5 was not released in 2022; no substitute crosswalk.
D.C. has no source sample. Native age, SEX/GENDER, income and race labels are not harmonized.
Positive-weight support minimum 500 is not a precision or anonymity guarantee.
Per-model-class case counts are absent from the cached aggregates; none are claimed.
Unknown/removed groups stay in full denominators, not recovered or redistributed.
Positive-cell complementary holds apply within/across states and across weight-stage masks.
Complete permitted selected aggregate inputs, all held-query decisions, prior full AP package,
original native-verification provenance, maintained code, tests, results and checksums included.
No raw respondents, private fine cells, party-choice tables, population counts or fake intervals.
No cross-study/causal turnout trend, fixed cohort, observed staying home or local allocation.
python3 -m unittest discover -s tests -p test_ap_state_groups.py
python3 -m scripts.ap_state_groups --inputs inputs --output reproduced
